<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Saratov State University :: Online Contester</title>
<META content="text/html; charset=windows-1251" http-equiv=Content-Type>
<META NAME="keywords" CONTENT="???">
<META NAME="description" CONTENT="???">
<meta name="google-site-verification" content="YvG5TvZLtlRLnK2EX22Dz815tDU7UKdDeXE_yJQp3cQ" />
<meta name="verify-v1" content="MCzwwWrZt7qOC1A2HZusdjMbXjHR+zXtTCKpx2CRSEU=" />

  <link rel="stylesheet" href="/templates.css" type="text/css">
  <link rel="stylesheet" href="/js/ui.datepicker.css" type="text/css">
  <script type="text/javascript" language="javascript" src="/js/jquery.js"></script>
  <script type="text/javascript" language="javascript" src="/js/jquery.example.js"></script>
  <script type="text/javascript" language="javascript" src="/js/ui.datepicker.js"></script>

  <link rel="stylesheet" href="templates.css" type="text/css">
  <link rel="stylesheet" href="js/ui.datepicker.css" type="text/css">
  <script type="text/javascript" language="javascript" src="js/jquery.js"></script>
  <script type="text/javascript" language="javascript" src="js/jquery.example.js"></script>
  <script type="text/javascript" language="javascript" src="js/ui.datepicker.js"></script>
<!--[if IE 6]>
<script type="text/javascript"> 
    /*Load jQuery if not already loaded*/ if(typeof jQuery == 'undefined'){ document.write("<script type=\"text/javascript\"   src=\"http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js\"></"+"script>"); var __noconflict = true; } 
    var IE6UPDATE_OPTIONS = {
        icons_path: "http://static.ie6update.com/hosted/ie6update/images/"
    }
</script>
<script type="text/javascript" src="http://static.ie6update.com/hosted/ie6update/ie6update.js"></script>
<![endif]-->
<link rel="stylesheet" href="style-1024.css" type="text/css">
</head>      <body bgcolor=#F3F6F9 text=#000000 link=#336699 vlink=#336699 alink=#336699><div align="center">
    <table width=984 class=tb cellpadding=0 cellspacing=0><tr><td><table width=984 cellspacing=1 ><tr><td bgcolor=#6587B9> <h3 align=center><font face='Geneva'><b style='color: White'>Saratov State University :: Online Contester</b></font></h3></td></tr></table></td></tr></table><br>    
<table width="974" border="0" cellpadding="0" cellspacing="0">
<tr>
<td valign="top">
<table width=153.6 class=tb cellpadding=0 cellspacing=0><tr><td><table width=153.6 cellspacing=1 ><tr><td bgcolor=#6587B9> ::Go</td></tr><tr><td bgcolor=#FFFFFF> - <a href = index.php> home </a><br>- <a href = problemset.php?contest=39> problems </a><br>- <a href = submit.php?contest=39> submit </a><br>- <a href = statusx.php?id=> personal status (<font color='red'>new</font>)</a><br>- <a href = status.php?contest=39> status </a><br>- <a href = monitor.php?contest=39 target=_blank> ranklist</a><br>- <a href = cpastcontests.php> past contests </a><br>- <a href = clarifications.php?contest=39> clarifications </a></td></tr></table></td></tr></table><br></td> <!-- close left colomn -->
<td width=5><img src="pixel.gif" alt="" width=5 height=1></td>
<td valign="top">
<table width=640 class=tb cellpadding=0 cellspacing=0><tr><td><table width=640 cellspacing=1 ><tr><td bgcolor=#6587B9> <div align=left class=dh>::past contests</div></td></tr><tr><td bgcolor=#FFFFFF> <BR>
<H5 style="COLOR: #000000" align=center>
<H5 style='COLOR: #000000' align=center>2013-11-15 16:57:53<BR></H5></H5>

<H5 style="COLOR: #000000" align=center>Past Contests</H5>
<TABLE  border="0" CELLPADDING = 3  width=90% align=center>
<TR bgcolor=#6587B9>
<TD>ID: </TD>
<TD>Start Date: </TD>
<TD>Finish Date: </TD>
<TD>Duration: </TD>
<TD>Title: </TD>
</TR>
<tr class=st1><td>39</td><td>2012-10-22 16:00:00</td><td>2012-10-22 21:00:00</td><td>5:00:00</td><td>      <a href=monitor.php?contest=39>Southern Subregional Programming Contest 2012</a>
    </td></tr><tr class=st0><td>38</td><td>2011-10-23 12:00:00</td><td>2011-10-23 17:00:00</td><td>5:00:00</td><td>      <a href=monitor.php?contest=38>Southern Subregional Programming Contest 2011</a>
    </td></tr><tr class=st1><td>37</td><td>2010-10-23 11:00:00</td><td>2010-10-23 16:00:00</td><td>5:00:00</td><td>      <a href=monitor.php?contest=37>Southern Subregional Programming Contest 2010</a>
    </td></tr><tr class=st0><td>36</td><td>2009-12-27 12:00:00</td><td>2009-12-27 17:00:00</td><td>5:00:00</td><td>      <a href=monitor.php?contest=36>Petr Mitrichev Contest 6</a>
    </td></tr><tr class=st1><td>35</td><td>2009-12-20 12:00:00</td><td>2009-12-20 17:00:00</td><td>5:00:00</td><td>      <a href=monitor.php?contest=35>Petr, Michael_Levin and NSI Contest (aka Petr Mitrichev Contest 5)</a>
    </td></tr><tr class=st0><td>34</td><td>2009-11-07 12:00:00</td><td>2009-11-07 17:00:00</td><td>5:00:00</td><td>      <a href=monitor.php?contest=34>Western Subregional Programming Contest 2009</a>
    </td></tr><tr class=st1><td>33</td><td>2009-10-30 12:00:00</td><td>2009-10-30 17:00:00</td><td>5:00:00</td><td>      <a href=monitor.php?contest=33>Halloween Contest 2009</a>
    </td></tr><tr class=st0><td>32</td><td>2009-10-23 12:00:00</td><td>2009-10-23 17:00:00</td><td>5:00:00</td><td>      <a href=monitor.php?contest=32>Goryinyich Challenge X</a>
    </td></tr><tr class=st1><td>31</td><td>2009-10-11 12:00:00</td><td>2009-10-11 17:00:00</td><td>5:00:00</td><td>      <a href=monitor.php?contest=31>Southern Subregional Programming Contest 2009</a>
    </td></tr><tr class=st0><td>30</td><td>2009-09-25 11:00:00</td><td>2009-09-25 16:00:00</td><td>5:00:00</td><td>      <a href=monitor.php?contest=30>Japanese Contest For Petrozavodsk Camp #3</a>
    </td></tr><tr class=st1><td>29</td><td>2009-03-22 11:00:00</td><td>2009-03-22 16:00:00</td><td>5:00:00</td><td>      <a href=monitor.php?contest=29>Izhevsk State Technical University Contest 3</a>
    </td></tr><tr class=st0><td>28</td><td>2009-03-15 11:00:00</td><td>2009-03-15 16:00:00</td><td>5:00:00</td><td>      <a href=monitor.php?contest=28>Petr, Michael_Levin and VitalyGoldstein Contest (aka Petr Mitrichev Contest 4)</a>
    </td></tr><tr class=st1><td>27</td><td>2009-03-01 11:00:00</td><td>2009-03-01 16:00:00</td><td>5:00:00</td><td>      <a href=monitor.php?contest=27>Petr Mitrichev Contest 3 (including problems by Michael Levin and Irina Shitova)</a>
    </td></tr><tr class=st0><td>26</td><td>2008-10-26 11:00:00</td><td>2008-10-26 16:00:00</td><td>5:00:00</td><td>      <a href=monitor.php?contest=26>Saratov School Regional Contest 2008</a>
    </td></tr><tr class=st1><td>25</td><td>2008-10-20 15:00:00</td><td>2008-10-20 20:00:00</td><td>5:00:00</td><td>      <a href=monitor.php?contest=25>Southern Subregional Programming Contest 2008</a>
    </td></tr><tr class=st0><td>24</td><td>2008-10-12 11:00:00</td><td>2008-10-12 16:00:00</td><td>5:00:00</td><td>      <a href=monitor.php?contest=24>MSU Unpredictable Contest</a>
    </td></tr><tr class=st1><td>23</td><td>2008-08-31 11:00:00</td><td>2008-08-31 16:00:00</td><td>5:00:00</td><td>      <a href=monitor.php?contest=23>Goodbye Summer 2008 Contest</a>
    </td></tr><tr class=st0><td>22</td><td>2007-10-28 11:00:00</td><td>2007-10-28 16:00:00</td><td>5:00:00</td><td>      <a href=monitor.php?contest=22>Saratov School Regional Contest 2007</a>
    </td></tr><tr class=st1><td>21</td><td>2007-10-21 12:00:00</td><td>2007-10-21 17:00:00</td><td>5:00:00</td><td>      <a href=monitor.php?contest=21>Southern Subregional Programming Contest 2007</a>
    </td></tr><tr class=st0><td>20</td><td>2007-02-03 11:00:00</td><td>2007-02-03 16:00:00</td><td>5:00:00</td><td>      <a href=monitor.php?contest=20>Saratov for Karelia with love</a>
    </td></tr><tr class=st1><td>19</td><td>2007-01-30 11:00:00</td><td>2007-01-30 16:00:00</td><td>5:00:00</td><td>      <a href=monitor.php?contest=19>Petr Mitrichev Contest 2</a>
    </td></tr><tr class=st0><td>18</td><td>2006-10-15 11:00:00</td><td>2006-10-15 16:15:00</td><td>5:15:00</td><td>      <a href=monitor.php?contest=18>9th Southern Subregional Programming Contest</a>
    </td></tr><tr class=st1><td>17</td><td>2006-10-01 12:00:00</td><td>2006-10-01 17:00:00</td><td>5:00:00</td><td>      <a href=monitor.php?contest=17>Petr Mitrichev Contest 1</a>
    </td></tr><tr class=st0><td>16</td><td>2005-10-16 11:00:00</td><td>2005-10-16 16:00:00</td><td>5:00:00</td><td>      <a href=monitor.php?contest=16>8th Southern Subregional Programming Contest</a>
    </td></tr><tr class=st1><td>15</td><td>2005-10-08 11:00:00</td><td>2005-10-08 16:00:00</td><td>5:00:00</td><td>      <a href=monitor.php?contest=15>Anton Golubev (Hedgehog)'s Contest</a>
    </td></tr><tr class=st0><td>14</td><td>2005-02-27 12:00:00</td><td>2005-02-27 17:00:00</td><td>5:00:00</td><td>      <a href=monitor.php?contest=14>Novosibirsk SU Contest #2</a>
    </td></tr><tr class=st1><td>13</td><td>2004-10-09 10:00:00</td><td>2004-10-09 15:00:00</td><td>5:00:00</td><td>      <a href=monitor.php?contest=13>7th Southern Subregional Programming Contest</a>
    </td></tr><tr class=st0><td>12</td><td>2004-10-02 10:00:00</td><td>2004-10-02 15:00:00</td><td>5:00:00</td><td>      <a href=monitor.php?contest=12>Saratov SU Contest: Golden Fall 2004</a>
    </td></tr><tr class=st1><td>11</td><td>2004-09-11 10:00:00</td><td>2004-09-11 15:00:00</td><td>5:00:00</td><td>      <a href=monitor.php?contest=11>SPbETU Contest #2</a>
    </td></tr><tr class=st0><td>10</td><td>2004-02-07 11:00:00</td><td>2004-02-07 16:00:00</td><td>5:00:00</td><td>      <a href=monitor.php?contest=10>World Finals warm-up contest of SPbETU#1</a>
    </td></tr><tr class=st1><td>9</td><td>2004-01-26 17:05:00</td><td>2004-01-26 20:05:00</td><td>3:00:00</td><td>      <a href=monitor.php?contest=9>SSU Winter 2004 Contest</a>
    </td></tr><tr class=st0><td>8</td><td>2003-10-12 11:30:00</td><td>2003-10-12 16:30:00</td><td>5:00:00</td><td>      <a href=monitor.php?contest=8>6th Southern Subregional Contest</a>
    </td></tr><tr class=st1><td>7</td><td>2003-05-18 10:00:00</td><td>2003-05-18 16:00:00</td><td>6:00:00</td><td>      <a href=monitor.php?contest=7>Spring Saratov ST team Contest</a>
    </td></tr><tr class=st0><td>6</td><td>2003-02-23 11:00:00</td><td>2003-02-23 16:00:00</td><td>5:00:00</td><td>      <a href=monitor.php?contest=6>NNSU : Three pigs contest</a>
    </td></tr><tr class=st1><td>5</td><td>2003-02-16 10:00:00</td><td>2003-02-16 15:00:00</td><td>5:00:00</td><td>      <a href=monitor.php?contest=5>Subregional School Contest '02</a>
    </td></tr><tr class=st0><td>3</td><td>2002-11-17 10:00:00</td><td>2002-11-17 17:00:00</td><td>7:00:00</td><td>      <a href=monitor.php?contest=3>Fall Contest #2</a>
    </td></tr><tr class=st1><td>2</td><td>2002-10-27 11:00:00</td><td>2002-10-27 16:00:00</td><td>5:00:00</td><td>      <a href=monitor.php?contest=2>5th Southern Subregional Contest</a>
    </td></tr><tr class=st0><td>1</td><td>2002-10-13 11:00:00</td><td>2002-10-13 16:00:00</td><td>5:00:00</td><td>      <a href=monitor.php?contest=1>Fall Contest #1</a>
    </td></tr></TABLE>
<br>

</td></tr></table></td></tr></table><br></td> <!-- close middle colomn -->
<td width=5><img src="pixel.gif" alt="" width=5 height=1></td>
<td valign="top">
<table width=153.6 class=tb cellpadding=0 cellspacing=0><tr><td><table width=153.6 cellspacing=1 ><tr><td bgcolor=#6587B9> ::Login</td></tr><tr><td bgcolor=#FFFFFF> <style>form.login input{margin:2px;font-size:10px;}</style>    <form class=login action=login.php method=post>
    your id:<br>
    <input type=hidden name=redirect_uri value='/cpastcontests.php'>
    <input class=inp style="width: 104px; height: 18px; font-size: 10px" maxLength=16 size=5 name=try_user_id value=''>
    <br>
    password:<br>
    <input class=inp style="width: 62px; height: 18px; font-size: 10px" type=password maxLength=16 size=3 name=try_user_password value=''>
    <input type=hidden name=type_log value="login">
    <input class=frm style="width: 45px" type=submit value=Login> 
    </form>
    <a style="font-size:10px;position:relative;bottom:5px;left:2px;" href="forgot_password.php">Forgot password?</a>
    </td></tr></table></td></tr></table><br></tr>
</table><table width=984 class=tb cellpadding=0 cellspacing=0><tr><td><table width=984 cellspacing=1 ><tr><td bgcolor=#FFFFFF> <table width=100% cellpadding=0 cellspacing=0 border=0><tr style='background-color : #FFFFFF;'><td align=left>Server time: 2013-11-15 16:57:53</td><td align=right><a target=_top href='mailto:acm@sgu.ru'>Online Contester</a> Team &copy; 2002 - 2013. All rights reserved.</td></tr></table></td></tr></table></td></tr></table></div></body></html> 
