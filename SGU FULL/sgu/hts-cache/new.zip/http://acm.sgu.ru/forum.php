<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Saratov State University :: Online Contester</title>
<META content="text/html; charset=windows-1251" http-equiv=Content-Type>
<META NAME="keywords" CONTENT="???">
<META NAME="description" CONTENT="???">
<meta name="google-site-verification" content="YvG5TvZLtlRLnK2EX22Dz815tDU7UKdDeXE_yJQp3cQ" />
<meta name="verify-v1" content="MCzwwWrZt7qOC1A2HZusdjMbXjHR+zXtTCKpx2CRSEU=" />

  <link rel="stylesheet" href="/templates.css" type="text/css">
  <link rel="stylesheet" href="/js/ui.datepicker.css" type="text/css">
  <script type="text/javascript" language="javascript" src="/js/jquery.js"></script>
  <script type="text/javascript" language="javascript" src="/js/jquery.example.js"></script>
  <script type="text/javascript" language="javascript" src="/js/ui.datepicker.js"></script>

  <link rel="stylesheet" href="templates.css" type="text/css">
  <link rel="stylesheet" href="js/ui.datepicker.css" type="text/css">
  <script type="text/javascript" language="javascript" src="js/jquery.js"></script>
  <script type="text/javascript" language="javascript" src="js/jquery.example.js"></script>
  <script type="text/javascript" language="javascript" src="js/ui.datepicker.js"></script>
<!--[if IE 6]>
<script type="text/javascript"> 
    /*Load jQuery if not already loaded*/ if(typeof jQuery == 'undefined'){ document.write("<script type=\"text/javascript\"   src=\"http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js\"></"+"script>"); var __noconflict = true; } 
    var IE6UPDATE_OPTIONS = {
        icons_path: "http://static.ie6update.com/hosted/ie6update/images/"
    }
</script>
<script type="text/javascript" src="http://static.ie6update.com/hosted/ie6update/ie6update.js"></script>
<![endif]-->
<link rel="stylesheet" href="style-1024.css" type="text/css">
</head>      <body bgcolor=#F3F6F9 text=#000000 link=#336699 vlink=#336699 alink=#336699><div align="center">
    <table width=984 class=tb cellpadding=0 cellspacing=0><tr><td><table width=984 cellspacing=1 ><tr><td bgcolor=#6587B9> <h3 align=center><font face='Geneva'><b style='color: White'>Saratov State University :: Online Contester</b></font></h3></td></tr></table></td></tr></table><br>    
<table width="974" border="0" cellpadding="0" cellspacing="0">
<tr>
<td valign="top">
<table width=153.6 class=tb cellpadding=0 cellspacing=0><tr><td><table width=153.6 cellspacing=1 ><tr><td bgcolor=#6587B9> ::Go</td></tr><tr><td bgcolor=#FFFFFF> - <a href = index.php> home </a><br>- <a href = news.php> news </a><br>- <a href = 'register.php'> register </a><br><table border=0 cellpadding=0 cellspacing=0><tr><td valign=top>-</td><td>&nbsp;</td><td><a href = 'update.php'>update personal info</a></td></tr></table><table border=0 cellpadding=0 cellspacing=0><tr><td valign=top>-</td><td>&nbsp;</td><td><a href = 'problemset.php?show_volumes'>problemset archive</a></td></tr></table>- <a href = submit.php> submit </a><br>- <a href = status.php> status online </a><br>- <a href = standing.php> standing </a><br>- <a href = contests.php> contests </a><br>- <a href = vcontests.php> virtual contests </a><br>- <a href = forum.php> forum </a><br>- <a href = statistic.php> statistic </a><br>- <a href = faq.php> FAQ </a><br>- <a href = links.php> links </a><br>- <a href = projects.php> projects </a></table></td></tr></table><br><table width=153.6 class=tb cellpadding=0 cellspacing=0><tr><td><table width=153.6 cellspacing=1 >
<tr><td bgcolor=#6587B9> ::Poll</td></tr>  <tr><td bgcolor=#FFFFFF> Are you registered on <a href="http://codeforces.com">Codeforces</a>?<br><form action=poll_action.php method=post target=_blank><input type=hidden name=poll value=14><input type=radio name=choose value=1 checked>Yes<br><input type=radio name=choose value=2 >No<br><input type=radio name=choose value=3 >What is it???<br><input type=submit value=Send class='frm' style='width:70px; font: 9;'><a href = poll_result.php?poll=14><br>[results]</a></form></td></tr></table></td></tr></table><br></td> <!-- close left colomn -->
<td width=5><img src="pixel.gif" alt="" width=5 height=1></td>
<td valign="top">
<table width=640 class=tb cellpadding=0 cellspacing=0><tr><td><table width=640 cellspacing=1 ><tr><td bgcolor=#6587B9> <div align=left class=dh>::webboard</div></td></tr><tr><td bgcolor=#FFFFFF> <br>
<script language=JavaScript>
function ShowConfirm(){
  return 1;
  return confirm("Are you sure that you want see all sub-tree of messages? Press CANCEL if you want to see only that message.");
};
</script>

<table border=1 width=98% align=center><ul><li><B><a href=forum_action.php?id=5042> to ADMINS </a></B> - bat2009fifa -  Contest: 0 -  Problem: 183 - 2013-11-14 18:13:49<li><B><a href=forum_action.php?id=5041> runtime error on test 6????? </a></B> -   -  Contest: 0 -  Problem: 231 - 2013-11-13 21:33:35<li><B><a href=forum_action.php?id=5040> bad test cases </a></B> - Night Fox -  Contest: 0 -  Problem: 138 - 2013-11-10 18:36:40<li><B><a href=forum_action.php?id=5039> [empty subj.] </a></B> - S4L1V4N -  Contest: 7 -  - 2013-11-08 13:56:38<li><B><a href=forum_action.php?id=5038> To Administrator. Add new country please </a></B> - Jamik -  -  - 2013-11-08 09:04:19<li><B><a href=forum_action.php?id=5037> contest 2013 </a></B> - r1d1 -  -  - 2013-10-28 08:36:18<li><B><a href=forum_action.php?id=5035> test </a></B> - Milad -  Contest: 0 -  Problem: 105 - 2013-10-23 01:54:30<li><B><a href=forum_action.php?id=5034> Cage </a></B> - amirmd76 -  Contest: 0 -  Problem: 186 - 2013-10-17 11:40:50<li><B><a href=forum_action.php?id=5033> Correct or incorrect </a></B> - Sunnat -  Contest: 0 -  Problem: 103 - 2013-10-10 18:51:26<li><B><a href=forum_action.php?id=5032> Why I have two ID? </a></B> - irony -  Contest: 0 -  - 2013-10-09 09:20:02<li><B><a href=forum_action.php?id=5030> is this algorithm correct? </a></B> - soroush -  Contest: 0 -  Problem: 165 - 2013-09-23 00:44:01<li><B><a href=forum_action.php?id=5029> WA1. What is wrong? </a></B> - mikroz -  Contest: 0 -  Problem: 397 - 2013-09-01 16:42:26<li><B><a href=forum_action.php?id=5028> why &quot;Wrong answer on test 1&quot;?? </a></B> - SkyCode -  Contest: 0 -  Problem: 325 - 2013-08-30 10:56:57<li><B><a href=forum_action.php?id=5026> why runtime eror </a></B> - Dementor -  Contest: 0 -  Problem: 126 - 2013-08-21 10:39:48<ul><li><B><a href=forum_action.php?id=5027> Re: why runtime eror </a></B> - electron -  Contest: 0 -  Problem: 126 - 2013-08-29 10:13:03</ul></ul></table><table width=90%><tr><td>      <a href=forum.php?page=1>
      <B>[<I>1</I>]</B></a>      <a href=forum.php?page=2>
      [2]</a>      <a href=forum.php?page=3>
      [3]</a>      <a href=forum.php?page=4>
      [4]</a>      <a href=forum.php?page=5>
      [5]</a>      <a href=forum.php?page=6>
      [6]</a>      <a href=forum.php?page=7>
      [7]</a>      <a href=forum.php?page=8>
      [8]</a>      <a href=forum.php?page=9>
      [9]</a>      <a href=forum.php?page=10>
      [10]</a>      <a href=forum.php?page=11>
      [11]</a>      <a href=forum.php?page=12>
      [12]</a>      <a href=forum.php?page=13>
      [13]</a>      <a href=forum.php?page=14>
      [14]</a>      <a href=forum.php?page=15>
      [15]</a>      <a href=forum.php?page=16>
      [16]</a>      <a href=forum.php?page=17>
      [17]</a>      <a href=forum.php?page=18>
      [18]</a>      <a href=forum.php?page=19>
      [19]</a>      <a href=forum.php?page=20>
      [20]</a>      <a href=forum.php?page=21>
      ...</td></tr></table>
<table height=10%><tr><td></td></tr></table>
<table width=90% align=center>
    <tr>
        <td align=center>
            <form action="forum_action.php" method='get'>
                <input type=hidden name=id value=0>
                <input type=hidden name=submitted value=2>
                <input type=submit value='post message' class=frm>
            </form>
        </td>
    </tr>
</table>

</td></tr></table></td></tr></table><br></td> <!-- close middle colomn -->
<td width=5><img src="pixel.gif" alt="" width=5 height=1></td>
<td valign="top">
<table width=153.6 class=tb cellpadding=0 cellspacing=0><tr><td><table width=153.6 cellspacing=1 ><tr><td bgcolor=#6587B9> ::Login</td></tr><tr><td bgcolor=#FFFFFF> <style>form.login input{margin:2px;font-size:10px;}</style>    <form class=login action=login.php method=post>
    your id:<br>
    <input type=hidden name=redirect_uri value='/forum.php'>
    <input class=inp style="width: 104px; height: 18px; font-size: 10px" maxLength=16 size=5 name=try_user_id value=''>
    <br>
    password:<br>
    <input class=inp style="width: 62px; height: 18px; font-size: 10px" type=password maxLength=16 size=3 name=try_user_password value=''>
    <input type=hidden name=type_log value="login">
    <input class=frm style="width: 45px" type=submit value=Login> 
    </form>
    <a style="font-size:10px;position:relative;bottom:5px;left:2px;" href="forgot_password.php">Forgot password?</a>
    </td></tr></table></td></tr></table><br><table width=153.6 class=tb cellpadding=0 cellspacing=0><tr><td><table width=153.6 cellspacing=1 >
<tr><td bgcolor=#6587B9> ::News</td></tr><tr><td bgcolor=#FFFFFF> <b>22.10.12</b> - The problems from the Southern Subregional Programming Contest 2012 added to the problemset archive (542 - 553). <br><b>22.10.12</b> - After the start of the contest the statements in PDF will be available <a href="http://acm.sgu.ru/problems/39/problems39.pdf">by the link</a>.<br><b>23.10.11</b> - The problems from the Southern Subregional Programming Contest 2011 added to the problemset archive (530 - 541).
<br></td></tr></table></td></tr></table><br><table width=153.6 class=tb cellpadding=0 cellspacing=0><tr><td><table width=153.6 cellspacing=1 >
<tr><td bgcolor=#6587B9> ::Counter</td></tr><tr><td bgcolor=#FFFFFF> 
<table align=center>
<tr>
<td>
<!-- google -->
<script src="http://www.google-analytics.com/urchin.js" type="text/javascript">
</script>
<script type="text/javascript">
_uacct = "UA-743380-1";
urchinTracker();
</script>
<!-- SpyLOG f:0211 --> 
<script language="javascript"><!-- 
Mu="u4199.99.spylog.com";Md=document;Mnv=navigator;Mp=0; 
Md.cookie="b=b";Mc=0;if(Md.cookie)Mc=1;Mrn=Math.random(); 
Mn=(Mnv.appName.substring(0,2)=="Mi")?0:1;Mt=(new Date()).getTimezoneOffset(); 
Mz="p="+Mp+"&rn="+Mrn+"&c="+Mc+"&t="+Mt; 
if(self!=top){Mfr=1;}else{Mfr=0;}Msl="1.0"; 
//--></script><script language="javascript1.1"><!-- 
Mpl="";Msl="1.1";Mj = (Mnv.javaEnabled()?"Y":"N");Mz+='&j='+Mj; 
//--></script><script language="javascript1.2"><!-- 
Msl="1.2";Ms=screen;Mpx=(Mn==0)?Ms.colorDepth:Ms.pixelDepth; 
Mz+="&wh="+Ms.width+'x'+Ms.height+"&px="+Mpx; 
//--></script><script language="javascript1.3"><!-- 
Msl="1.3";//--></script><script language="javascript"><!-- 
My="";My+="<a href='http://"+Mu+"/cnt?cid=419999&f=3&p="+Mp+"&rn="+Mrn+"' target='_blank'>"; 
My+="<img src='http://"+Mu+"/cnt?cid=419999&"+Mz+"&sl="+Msl+"&r="+escape(Md.referrer)+"&fr="+Mfr+"&pg="+escape(window.location.href); 
My+="' border=0 width=88 height=31 alt='SpyLOG'>"; 
My+="</a>";Md.write(My);//--></script><noscript> 
<a href="http://u4199.99.spylog.com/cnt?cid=419999&f=3&p=0" target="_blank"> 
<img src="http://u4199.99.spylog.com/cnt?cid=419999&p=0" alt='SpyLOG' border='0' width=88 height=31 > 
</a></noscript> 
<!-- SpyLOG -->

</td>
</tr>
</table>

<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
var pageTracker = _gat._getTracker("UA-5412771-1");
pageTracker._trackPageview();
</script>

  </td></tr></table></td></tr></table><br></tr>
</table><table width=984 class=tb cellpadding=0 cellspacing=0><tr><td><table width=984 cellspacing=1 ><tr><td bgcolor=#FFFFFF> <table width=100% cellpadding=0 cellspacing=0 border=0><tr style='background-color : #FFFFFF;'><td align=left>Server time: 2013-11-15 16:35:38</td><td align=right><a target=_top href='mailto:acm@sgu.ru'>Online Contester</a> Team &copy; 2002 - 2013. All rights reserved.</td></tr></table></td></tr></table></td></tr></table></div></body></html>