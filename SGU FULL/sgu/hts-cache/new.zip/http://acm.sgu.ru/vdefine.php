<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Saratov State University :: Online Contester</title>
<META content="text/html; charset=windows-1251" http-equiv=Content-Type>
<META NAME="keywords" CONTENT="???">
<META NAME="description" CONTENT="???">
<meta name="google-site-verification" content="YvG5TvZLtlRLnK2EX22Dz815tDU7UKdDeXE_yJQp3cQ" />
<meta name="verify-v1" content="MCzwwWrZt7qOC1A2HZusdjMbXjHR+zXtTCKpx2CRSEU=" />

  <link rel="stylesheet" href="/templates.css" type="text/css">
  <link rel="stylesheet" href="/js/ui.datepicker.css" type="text/css">
  <script type="text/javascript" language="javascript" src="/js/jquery.js"></script>
  <script type="text/javascript" language="javascript" src="/js/jquery.example.js"></script>
  <script type="text/javascript" language="javascript" src="/js/ui.datepicker.js"></script>

  <link rel="stylesheet" href="templates.css" type="text/css">
  <link rel="stylesheet" href="js/ui.datepicker.css" type="text/css">
  <script type="text/javascript" language="javascript" src="js/jquery.js"></script>
  <script type="text/javascript" language="javascript" src="js/jquery.example.js"></script>
  <script type="text/javascript" language="javascript" src="js/ui.datepicker.js"></script>
<!--[if IE 6]>
<script type="text/javascript"> 
    /*Load jQuery if not already loaded*/ if(typeof jQuery == 'undefined'){ document.write("<script type=\"text/javascript\"   src=\"http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js\"></"+"script>"); var __noconflict = true; } 
    var IE6UPDATE_OPTIONS = {
        icons_path: "http://static.ie6update.com/hosted/ie6update/images/"
    }
</script>
<script type="text/javascript" src="http://static.ie6update.com/hosted/ie6update/ie6update.js"></script>
<![endif]-->
<link rel="stylesheet" href="style-1024.css" type="text/css">
</head>      <body bgcolor=#F3F6F9 text=#000000 link=#336699 vlink=#336699 alink=#336699><div align="center">
    <table width=984 class=tb cellpadding=0 cellspacing=0><tr><td><table width=984 cellspacing=1 ><tr><td bgcolor=#6587B9> <h3 align=center><font face='Geneva'><b style='color: White'>Saratov State University :: Online Contester</b></font></h3></td></tr></table></td></tr></table><br>    
<table width="974" border="0" cellpadding="0" cellspacing="0">
<tr>
<td valign="top">
<table width=153.6 class=tb cellpadding=0 cellspacing=0><tr><td><table width=153.6 cellspacing=1 ><tr><td bgcolor=#6587B9> ::Go</td></tr><tr><td bgcolor=#FFFFFF> - <a href = index.php> home </a><br>- <a href = v_avaliable.php> avaliable contests </a><br>- <a href = vdefine.php> define contest </a><br>- <a href = vdefined.php> defined contests </a><br>- <a href = problemset.php?virt=1> problemset </a><br>- <a href = submit.php?virt=1> submit </a><br>- <a href = status.php?virt=1> status </a><br>- <a href = monitor-wo-virt.php?virt=1> ranklist </a></td></tr></table></td></tr></table><br></td> <!-- close left colomn -->
<td width=5><img src="pixel.gif" alt="" width=5 height=1></td>
<td valign="top">
<table width=640 class=tb cellpadding=0 cellspacing=0><tr><td><table width=640 cellspacing=1 ><tr><td bgcolor=#6587B9> <div align=left class=dh>::define virtual contest</div></td></tr><tr><td bgcolor=#FFFFFF> 

<TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
  <TBODY>
  <TR>
    <TD width=100>&nbsp;</TD>
    <TD><BR><BR>
      <H4 align=center>Define virtual contest</H4><BR>
      <FORM action=vdefcontest.php method=post><INPUT type=hidden value=1 name=register> 
      <TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
        <TBODY>
        <TR>
          <TD width=100>Your ID:</TD>
          <TD><INPUT name=id class=inp value=''></TD></TR>
        <TR>
          <TD>Contest:</TD>
          <TD><SELECT name=contest><OPTION value='-1'> <OPTION value='1'>1 Fall Contest #1</OPTION><OPTION value='2'>2 5th Southern Subregional Contest</OPTION><OPTION value='3'>3 Fall Contest #2</OPTION><OPTION value='5'>5 Subregional School Contest '02</OPTION><OPTION value='6'>6 NNSU : Three pigs contest</OPTION><OPTION value='7'>7 Spring Saratov ST team Contest</OPTION><OPTION value='8'>8 6th Southern Subregional Contest</OPTION><OPTION value='9'>9 SSU Winter 2004 Contest</OPTION><OPTION value='10'>10 World Finals warm-up contest of SPbETU#1</OPTION><OPTION value='11'>11 SPbETU Contest #2</OPTION><OPTION value='12'>12 Saratov SU Contest: Golden Fall 2004</OPTION><OPTION value='13'>13 7th Southern Subregional Programming Contest</OPTION><OPTION value='14'>14 Novosibirsk SU Contest #2</OPTION><OPTION value='15'>15 Anton Golubev (Hedgehog)'s Contest</OPTION><OPTION value='16'>16 8th Southern Subregional Programming Contest</OPTION><OPTION value='17'>17 Petr Mitrichev Contest 1</OPTION><OPTION value='18'>18 9th Southern Subregional Programming Contest</OPTION><OPTION value='19'>19 Petr Mitrichev Contest 2</OPTION><OPTION value='20'>20 Saratov for Karelia with love</OPTION><OPTION value='21'>21 Southern Subregional Programming Contest 2007</OPTION><OPTION value='22'>22 Saratov School Regional Contest 2007</OPTION><OPTION value='23'>23 Goodbye Summer 2008 Contest</OPTION><OPTION value='24'>24 MSU Unpredictable Contest</OPTION><OPTION value='25'>25 Southern Subregional Programming Contest 2008</OPTION><OPTION value='26'>26 Saratov School Regional Contest 2008</OPTION><OPTION value='27'>27 Petr Mitrichev Contest 3 (including problems by Michael Levin and Irina Shitova)</OPTION><OPTION value='28'>28 Petr, Michael_Levin and VitalyGoldstein Contest (aka Petr Mitrichev Contest 4)</OPTION><OPTION value='29'>29 Izhevsk State Technical University Contest 3</OPTION><OPTION value='30'>30 Japanese Contest For Petrozavodsk Camp #3</OPTION><OPTION value='31'>31 Southern Subregional Programming Contest 2009</OPTION><OPTION value='32'>32 Goryinyich Challenge X</OPTION><OPTION value='33'>33 Halloween Contest 2009</OPTION><OPTION value='34'>34 Western Subregional Programming Contest 2009</OPTION><OPTION value='35'>35 Petr, Michael_Levin and NSI Contest (aka Petr Mitrichev Contest 5)</OPTION><OPTION value='36'>36 Petr Mitrichev Contest 6</OPTION><OPTION value='37'>37 Southern Subregional Programming Contest 2010</OPTION><OPTION value='38'>38 Southern Subregional Programming Contest 2011</OPTION><OPTION value='39'>39 Southern Subregional Programming Contest 2012</OPTION></SELECT> </TD></TR>
        <TR>
          <TD colSpan=2><BR>
             If you have already got virtual contest with such "CONTEST" parameter then all your old results will be deleted.
            <BR></TD></TR>

        <TR>
          <TD colSpan=2><BR>
            <HR>
            <BR></TD></TR>

        <TR>
          <TD>Your Password:</TD>
          <TD><INPUT type=password class=inp name=pass value=''></TD></TR>
        <TR>
          <TD colSpan=2><BR>
            <HR>
            <BR></TD></TR>
        <TR><td><table><tr>
          <TD>Year:</TD>
          <TD><SELECT name=year><OPTION value=??> <OPTION value=2002>2002<OPTION value=2003>2003<OPTION value=2004>2004<OPTION value=2005>2005<OPTION value=2006>2006<OPTION value=2007>2007<OPTION value=2008>2008<OPTION value=2009>2009<OPTION value=2010>2010<OPTION value=2011>2011<OPTION value=2012>2012<OPTION value=2013 selected>2013</OPTION></SELECT> </TD><TD></TD>
          <TD>Month:</TD>
          <TD><SELECT name=month><OPTION value=??> <OPTION value=01>01<OPTION value=02>02<OPTION value=03>03<OPTION value=04>04<OPTION value=05>05<OPTION value=06>06<OPTION value=07>07<OPTION value=08>08<OPTION value=09>09<OPTION value=10>10<OPTION value=11 selected>11<OPTION value=12>12</OPTION></SELECT> </TD><TD></TD><TD>Day:</TD>
          <TD><SELECT name=day><OPTION value=??> <OPTION value=01>01<OPTION value=02>02<OPTION value=03>03<OPTION value=04>04<OPTION value=05>05<OPTION value=06>06<OPTION value=07>07<OPTION value=08>08<OPTION value=09>09<OPTION value=10>10<OPTION value=11>11<OPTION value=12>12<OPTION value=13>13<OPTION value=14>14<OPTION value=15 selected>15<OPTION value=16>16<OPTION value=17>17<OPTION value=18>18<OPTION value=19>19<OPTION value=20>20<OPTION value=21>21<OPTION value=22>22<OPTION value=23>23<OPTION value=24>24<OPTION value=25>25<OPTION value=26>26<OPTION value=27>27<OPTION value=28>28<OPTION value=29>29<OPTION value=30>30<OPTION value=31>31</OPTION></SELECT> </TD></tr></table></td>
        <td><table><tr>
          <TD>Hour:</TD>
          <TD><SELECT name=hour><OPTION value=??> <OPTION value=00>00<OPTION value=01>01<OPTION value=02>02<OPTION value=03>03<OPTION value=04>04<OPTION value=05>05<OPTION value=06>06<OPTION value=07>07<OPTION value=08>08<OPTION value=09>09<OPTION value=10>10<OPTION value=11>11<OPTION value=12>12<OPTION value=13>13<OPTION value=14>14<OPTION value=15>15<OPTION value=16 selected>16<OPTION value=17>17<OPTION value=18>18<OPTION value=19>19<OPTION value=20>20<OPTION value=21>21<OPTION value=22>22<OPTION value=23>23</OPTION></SELECT> </TD><TD></TD>
          <TD>Minute:</TD>
          <TD><SELECT name=minute><OPTION value=??> <OPTION value=00>00<OPTION value=01>01<OPTION value=02>02<OPTION value=03>03<OPTION value=04>04<OPTION value=05>05<OPTION value=06>06<OPTION value=07>07<OPTION value=08>08<OPTION value=09>09<OPTION value=10>10<OPTION value=11>11<OPTION value=12>12<OPTION value=13>13<OPTION value=14>14<OPTION value=15>15<OPTION value=16>16<OPTION value=17>17<OPTION value=18>18<OPTION value=19>19<OPTION value=20>20<OPTION value=21>21<OPTION value=22>22<OPTION value=23>23<OPTION value=24>24<OPTION value=25>25<OPTION value=26>26<OPTION value=27>27<OPTION value=28>28<OPTION value=29>29<OPTION value=30>30<OPTION value=31>31<OPTION value=32>32<OPTION value=33>33<OPTION value=34>34<OPTION value=35>35<OPTION value=36>36<OPTION value=37>37<OPTION value=38>38<OPTION value=39>39<OPTION value=40>40<OPTION value=41>41<OPTION value=42>42<OPTION value=43>43<OPTION value=44>44<OPTION value=45>45<OPTION value=46>46<OPTION value=47>47<OPTION value=48>48<OPTION value=49>49<OPTION value=50>50<OPTION value=51>51<OPTION value=52>52<OPTION value=53>53<OPTION value=54>54<OPTION value=55>55<OPTION value=56>56<OPTION value=57 selected>57<OPTION value=58>58<OPTION value=59>59</OPTION></SELECT> </TD></TR></table></td></tr>
          <TD colSpan=2><BR>
            <HR>
            <BR></TD></TR>
        <TR>
          <TD align=middle 
        colSpan=2><INPUT class=frm type=submit value=Register></TD></TR></TBODY></TABLE></FORM><BR><BR></TD>
    <TD width=100>&nbsp;</TD></TR>
  <TR>
    <TD colSpan=3>
    </TD></TR></TBODY></TABLE>

</td></tr></table></td></tr></table><br></td> <!-- close middle colomn -->
<td width=5><img src="pixel.gif" alt="" width=5 height=1></td>
<td valign="top">
<table width=153.6 class=tb cellpadding=0 cellspacing=0><tr><td><table width=153.6 cellspacing=1 ><tr><td bgcolor=#6587B9> ::Login</td></tr><tr><td bgcolor=#FFFFFF> <style>form.login input{margin:2px;font-size:10px;}</style>    <form class=login action=login.php method=post>
    your id:<br>
    <input type=hidden name=redirect_uri value='/vdefine.php'>
    <input class=inp style="width: 104px; height: 18px; font-size: 10px" maxLength=16 size=5 name=try_user_id value=''>
    <br>
    password:<br>
    <input class=inp style="width: 62px; height: 18px; font-size: 10px" type=password maxLength=16 size=3 name=try_user_password value=''>
    <input type=hidden name=type_log value="login">
    <input class=frm style="width: 45px" type=submit value=Login> 
    </form>
    <a style="font-size:10px;position:relative;bottom:5px;left:2px;" href="forgot_password.php">Forgot password?</a>
    </td></tr></table></td></tr></table><br></tr>
</table><table width=984 class=tb cellpadding=0 cellspacing=0><tr><td><table width=984 cellspacing=1 ><tr><td bgcolor=#FFFFFF> <table width=100% cellpadding=0 cellspacing=0 border=0><tr style='background-color : #FFFFFF;'><td align=left>Server time: 2013-11-15 16:57:55</td><td align=right><a target=_top href='mailto:acm@sgu.ru'>Online Contester</a> Team &copy; 2002 - 2013. All rights reserved.</td></tr></table></td></tr></table></td></tr></table></div></body></html> 