<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Saratov State University :: Online Contester</title>
<META content="text/html; charset=windows-1251" http-equiv=Content-Type>
<META NAME="keywords" CONTENT="???">
<META NAME="description" CONTENT="???">
<meta name="google-site-verification" content="YvG5TvZLtlRLnK2EX22Dz815tDU7UKdDeXE_yJQp3cQ" />
<meta name="verify-v1" content="MCzwwWrZt7qOC1A2HZusdjMbXjHR+zXtTCKpx2CRSEU=" />

  <link rel="stylesheet" href="/templates.css" type="text/css">
  <link rel="stylesheet" href="/js/ui.datepicker.css" type="text/css">
  <script type="text/javascript" language="javascript" src="/js/jquery.js"></script>
  <script type="text/javascript" language="javascript" src="/js/jquery.example.js"></script>
  <script type="text/javascript" language="javascript" src="/js/ui.datepicker.js"></script>

  <link rel="stylesheet" href="templates.css" type="text/css">
  <link rel="stylesheet" href="js/ui.datepicker.css" type="text/css">
  <script type="text/javascript" language="javascript" src="js/jquery.js"></script>
  <script type="text/javascript" language="javascript" src="js/jquery.example.js"></script>
  <script type="text/javascript" language="javascript" src="js/ui.datepicker.js"></script>
<!--[if IE 6]>
<script type="text/javascript"> 
    /*Load jQuery if not already loaded*/ if(typeof jQuery == 'undefined'){ document.write("<script type=\"text/javascript\"   src=\"http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js\"></"+"script>"); var __noconflict = true; } 
    var IE6UPDATE_OPTIONS = {
        icons_path: "http://static.ie6update.com/hosted/ie6update/images/"
    }
</script>
<script type="text/javascript" src="http://static.ie6update.com/hosted/ie6update/ie6update.js"></script>
<![endif]-->
<link rel="stylesheet" href="style-1024.css" type="text/css">
</head>      <body bgcolor=#F3F6F9 text=#000000 link=#336699 vlink=#336699 alink=#336699><div align="center">
    <table width=984 class=tb cellpadding=0 cellspacing=0><tr><td><table width=984 cellspacing=1 ><tr><td bgcolor=#6587B9> <h3 align=center><font face='Geneva'><b style='color: White'>Saratov State University :: Online Contester</b></font></h3></td></tr></table></td></tr></table><br>    
<table width="974" border="0" cellpadding="0" cellspacing="0">
<tr>
<td valign="top">
<table width=153.6 class=tb cellpadding=0 cellspacing=0><tr><td><table width=153.6 cellspacing=1 ><tr><td bgcolor=#6587B9> ::Go</td></tr><tr><td bgcolor=#FFFFFF> - <a href = index.php> home </a><br>- <a href = news.php> news </a><br>- <a href = 'register.php'> register </a><br><table border=0 cellpadding=0 cellspacing=0><tr><td valign=top>-</td><td>&nbsp;</td><td><a href = 'update.php'>update personal info</a></td></tr></table><table border=0 cellpadding=0 cellspacing=0><tr><td valign=top>-</td><td>&nbsp;</td><td><a href = 'problemset.php?show_volumes'>problemset archive</a></td></tr></table>- <a href = submit.php> submit </a><br>- <a href = status.php> status online </a><br>- <a href = standing.php> standing </a><br>- <a href = contests.php> contests </a><br>- <a href = vcontests.php> virtual contests </a><br>- <a href = forum.php> forum </a><br>- <a href = statistic.php> statistic </a><br>- <a href = faq.php> FAQ </a><br>- <a href = links.php> links </a><br>- <a href = projects.php> projects </a></table></td></tr></table><br><table width=153.6 class=tb cellpadding=0 cellspacing=0><tr><td><table width=153.6 cellspacing=1 >
<tr><td bgcolor=#6587B9> ::Poll</td></tr>  <tr><td bgcolor=#FFFFFF> Are you registered on <a href="http://codeforces.com">Codeforces</a>?<br><form action=poll_action.php method=post target=_blank><input type=hidden name=poll value=14><input type=radio name=choose value=1 checked>Yes<br><input type=radio name=choose value=2 >No<br><input type=radio name=choose value=3 >What is it???<br><input type=submit value=Send class='frm' style='width:70px; font: 9;'><a href = poll_result.php?poll=14><br>[results]</a></form></td></tr></table></td></tr></table><br></td> <!-- close left colomn -->
<td width=5><img src="pixel.gif" alt="" width=5 height=1></td>
<td valign="top">
<table width=640 class=tb cellpadding=0 cellspacing=0><tr><td><table width=640 cellspacing=1 ><tr><td bgcolor=#6587B9> <div align=left class=dh>::standing</div></td></tr><tr><td bgcolor=#FFFFFF> 
<BR>

<H5> Problemset Contest </H5>
<H4 align = center>standing</H4>

<H5  style="color : #000000" align=center>
2013-11-15 16:35:34<BR></H5>

<table align=right><tr><td>
</td></tr></table>
<TABLE  border="0" CELLPADDING = 4  width=90% align=center>
<TR bgcolor=#6587B9>
<TD width="5%">Rank: </TD>
<TD width="10%">Country: </TD>
<TD width="30%">Name: </TD>
<TD width="5%">AC: </TD>
<TD width="25%">Last Accepted: </TD>
</TR>
<TR class=st1>
  <TD>1</TD>
  <TD>CN</TD>
  <TD><a href=teaminfo.php?id=002135 onClick="href='teaminfo.php?id=002135'">Tiancheng LOU</a></TD>
  <TD>454</TD>
  <TD>2012-10-28 01:43:04</TD></TR>
  <TR class=st1>
  <TD>2</TD>
  <TD>CN</TD>
  <TD><a href=teaminfo.php?id=017741 onClick="href='teaminfo.php?id=017741'">try</a></TD>
  <TD>454</TD>
  <TD>2013-08-13 11:17:54</TD></TR>
  <TR class=st1>
  <TD>3</TD>
  <TD>CN</TD>
  <TD><a href=teaminfo.php?id=040258 onClick="href='teaminfo.php?id=040258'">scottai</a></TD>
  <TD>446</TD>
  <TD>2012-11-10 12:57:02</TD></TR>
  <TR class=st1>
  <TD>4</TD>
  <TD>UA</TD>
  <TD><a href=teaminfo.php?id=017976 onClick="href='teaminfo.php?id=017976'">awpris</a></TD>
  <TD>427</TD>
  <TD>2013-03-19 09:28:44</TD></TR>
  <TR class=st1>
  <TD>5</TD>
  <TD>CN</TD>
  <TD><a href=teaminfo.php?id=040852 onClick="href='teaminfo.php?id=040852'">Night_Fury</a></TD>
  <TD>426</TD>
  <TD>2012-04-02 16:57:01</TD></TR>
  <TR class=st1>
  <TD>6</TD>
  <TD>RU</TD>
  <TD><a href=teaminfo.php?id=045016 onClick="href='teaminfo.php?id=045016'">Lukianchikov_Vladimir_Orsk</a></TD>
  <TD>425</TD>
  <TD>2013-11-15 09:07:33</TD></TR>
  <TR class=st1>
  <TD>7</TD>
  <TD>CN</TD>
  <TD><a href=teaminfo.php?id=040532 onClick="href='teaminfo.php?id=040532'">zw7840</a></TD>
  <TD>417</TD>
  <TD>2011-03-12 13:21:11</TD></TR>
  <TR class=st1>
  <TD>8</TD>
  <TD>CN</TD>
  <TD><a href=teaminfo.php?id=018717 onClick="href='teaminfo.php?id=018717'">onp</a></TD>
  <TD>416</TD>
  <TD>2010-11-08 17:52:04</TD></TR>
  <TR class=st1>
  <TD>9</TD>
  <TD>BY</TD>
  <TD><a href=teaminfo.php?id=042665 onClick="href='teaminfo.php?id=042665'">Tooru Ichii</a></TD>
  <TD>407</TD>
  <TD>2013-08-09 16:50:21</TD></TR>
  <TR class=st1>
  <TD>10</TD>
  <TD>RU</TD>
  <TD><a href=teaminfo.php?id=009396 onClick="href='teaminfo.php?id=009396'">UdH-WiNGeR</a></TD>
  <TD>398</TD>
  <TD>2012-07-17 16:54:05</TD></TR>
  <TR class=st1>
  <TD>11</TD>
  <TD>AI</TD>
  <TD><a href=teaminfo.php?id=040407 onClick="href='teaminfo.php?id=040407'">vjudge3</a></TD>
  <TD>390</TD>
  <TD>2013-09-21 11:21:51</TD></TR>
  <TR class=st1>
  <TD>12</TD>
  <TD>CN</TD>
  <TD><a href=teaminfo.php?id=040406 onClick="href='teaminfo.php?id=040406'">vjudge2</a></TD>
  <TD>389</TD>
  <TD>2013-11-07 17:16:28</TD></TR>
  <TR class=st1>
  <TD>13</TD>
  <TD>CN</TD>
  <TD><a href=teaminfo.php?id=044848 onClick="href='teaminfo.php?id=044848'">data.h</a></TD>
  <TD>387</TD>
  <TD>2013-10-14 14:01:07</TD></TR>
  <TR class=st1>
  <TD>14</TD>
  <TD>CN</TD>
  <TD><a href=teaminfo.php?id=040405 onClick="href='teaminfo.php?id=040405'">vjudge1</a></TD>
  <TD>386</TD>
  <TD>2013-11-03 04:53:17</TD></TR>
  <TR class=st1>
  <TD>15</TD>
  <TD>CN</TD>
  <TD><a href=teaminfo.php?id=042714 onClick="href='teaminfo.php?id=042714'">_ _saturn mercury neptune pleiades -- bleedingversion X</a></TD>
  <TD>382</TD>
  <TD>2012-03-28 19:22:38</TD></TR>
  <TR class=st1>
  <TD>16</TD>
  <TD>AI</TD>
  <TD><a href=teaminfo.php?id=040408 onClick="href='teaminfo.php?id=040408'">vjudge4</a></TD>
  <TD>382</TD>
  <TD>2013-10-15 12:12:16</TD></TR>
  <TR class=st1>
  <TD>17</TD>
  <TD>RU</TD>
  <TD><a href=teaminfo.php?id=037629 onClick="href='teaminfo.php?id=037629'">Vladislav Epifanov</a></TD>
  <TD>381</TD>
  <TD>2011-04-22 22:11:30</TD></TR>
  <TR class=st1>
  <TD>18</TD>
  <TD>AI</TD>
  <TD><a href=teaminfo.php?id=040409 onClick="href='teaminfo.php?id=040409'">vjudge5</a></TD>
  <TD>381</TD>
  <TD>2013-10-25 12:07:35</TD></TR>
  <TR class=st1>
  <TD>19</TD>
  <TD>CN</TD>
  <TD><a href=teaminfo.php?id=057472 onClick="href='teaminfo.php?id=057472'">xqyink</a></TD>
  <TD>376</TD>
  <TD>2013-04-08 07:31:01</TD></TR>
  <TR class=st1>
  <TD>20</TD>
  <TD>CN</TD>
  <TD><a href=teaminfo.php?id=036318 onClick="href='teaminfo.php?id=036318'">WJMZBMR</a></TD>
  <TD>375</TD>
  <TD>2012-10-30 16:25:15</TD></TR>
  <TR class=st1>
  <TD>21</TD>
  <TD>CN</TD>
  <TD><a href=teaminfo.php?id=018177 onClick="href='teaminfo.php?id=018177'">joey2005</a></TD>
  <TD>366</TD>
  <TD>2012-07-17 04:49:20</TD></TR>
  <TR class=st1>
  <TD>22</TD>
  <TD>BY</TD>
  <TD><a href=teaminfo.php?id=003852 onClick="href='teaminfo.php?id=003852'">Gennady Korotkevich</a></TD>
  <TD>361</TD>
  <TD>2013-02-27 21:23:25</TD></TR>
  <TR class=st1>
  <TD>23</TD>
  <TD>CA</TD>
  <TD><a href=teaminfo.php?id=010257 onClick="href='teaminfo.php?id=010257'">Nicholas</a></TD>
  <TD>357</TD>
  <TD>2012-01-16 09:27:32</TD></TR>
  <TR class=st1>
  <TD>24</TD>
  <TD>CN</TD>
  <TD><a href=teaminfo.php?id=005224 onClick="href='teaminfo.php?id=005224'">Skywalker</a></TD>
  <TD>353</TD>
  <TD>2013-03-01 19:05:35</TD></TR>
  <TR class=st1>
  <TD>25</TD>
  <TD>PL</TD>
  <TD><a href=teaminfo.php?id=008877 onClick="href='teaminfo.php?id=008877'">wojtek</a></TD>
  <TD>349</TD>
  <TD>2010-11-21 11:52:11</TD></TR>
  <TR class=st1>
  <TD>26</TD>
  <TD>CN</TD>
  <TD><a href=teaminfo.php?id=007322 onClick="href='teaminfo.php?id=007322'">Chen Mingcheng</a></TD>
  <TD>342</TD>
  <TD>2009-03-28 13:05:22</TD></TR>
  <TR class=st1>
  <TD>27</TD>
  <TD>CN</TD>
  <TD><a href=teaminfo.php?id=017370 onClick="href='teaminfo.php?id=017370'">::HPF::</a></TD>
  <TD>341</TD>
  <TD>2011-10-23 16:53:06</TD></TR>
  <TR class=st1>
  <TD>28</TD>
  <TD>CN</TD>
  <TD><a href=teaminfo.php?id=040524 onClick="href='teaminfo.php?id=040524'">zzldjk</a></TD>
  <TD>335</TD>
  <TD>2011-10-24 12:26:02</TD></TR>
  <TR class=st1>
  <TD>29</TD>
  <TD>CN</TD>
  <TD><a href=teaminfo.php?id=040255 onClick="href='teaminfo.php?id=040255'">zrp</a></TD>
  <TD>331</TD>
  <TD>2012-02-01 08:46:15</TD></TR>
  <TR class=st1>
  <TD>30</TD>
  <TD>IR</TD>
  <TD><a href=teaminfo.php?id=014723 onClick="href='teaminfo.php?id=014723'">Solej</a></TD>
  <TD>322</TD>
  <TD>2009-10-12 23:44:20</TD></TR>
  <TR class=st1>
  <TD>31</TD>
  <TD>IR</TD>
  <TD><a href=teaminfo.php?id=007733 onClick="href='teaminfo.php?id=007733'">Ali</a></TD>
  <TD>322</TD>
  <TD>2013-04-21 17:31:05</TD></TR>
  <TR class=st1>
  <TD>32</TD>
  <TD>CN</TD>
  <TD><a href=teaminfo.php?id=042923 onClick="href='teaminfo.php?id=042923'">ztxz16</a></TD>
  <TD>320</TD>
  <TD>2013-10-10 15:22:44</TD></TR>
  <TR class=st1>
  <TD>33</TD>
  <TD>TW</TD>
  <TD><a href=teaminfo.php?id=038432 onClick="href='teaminfo.php?id=038432'">dreamoon</a></TD>
  <TD>316</TD>
  <TD>2012-08-18 03:10:01</TD></TR>
  <TR class=st1>
  <TD>34</TD>
  <TD>CN</TD>
  <TD><a href=teaminfo.php?id=052426 onClick="href='teaminfo.php?id=052426'">sjq</a></TD>
  <TD>315</TD>
  <TD>2013-11-10 13:31:57</TD></TR>
  <TR class=st1>
  <TD>35</TD>
  <TD>CN</TD>
  <TD><a href=teaminfo.php?id=011941 onClick="href='teaminfo.php?id=011941'">E478</a></TD>
  <TD>308</TD>
  <TD>2012-10-22 18:30:39</TD></TR>
  <TR class=st1>
  <TD>36</TD>
  <TD>CN</TD>
  <TD><a href=teaminfo.php?id=012093 onClick="href='teaminfo.php?id=012093'">wcwswswws</a></TD>
  <TD>308</TD>
  <TD>2012-10-22 20:18:45</TD></TR>
  <TR class=st1>
  <TD>37</TD>
  <TD>CN</TD>
  <TD><a href=teaminfo.php?id=018724 onClick="href='teaminfo.php?id=018724'">HYH</a></TD>
  <TD>305</TD>
  <TD>2012-10-31 10:22:12</TD></TR>
  <TR class=st1>
  <TD>38</TD>
  <TD>KZ</TD>
  <TD><a href=teaminfo.php?id=005140 onClick="href='teaminfo.php?id=005140'">arti</a></TD>
  <TD>305</TD>
  <TD>2013-08-12 17:39:40</TD></TR>
  <TR class=st1>
  <TD>39</TD>
  <TD>HK</TD>
  <TD><a href=teaminfo.php?id=004143 onClick="href='teaminfo.php?id=004143'">Murphy</a></TD>
  <TD>304</TD>
  <TD>2012-04-07 12:51:35</TD></TR>
  <TR class=st1>
  <TD>40</TD>
  <TD>RU</TD>
  <TD><a href=teaminfo.php?id=001470 onClick="href='teaminfo.php?id=001470'">Eugene Larchenko, exchanging solutions</a></TD>
  <TD>301</TD>
  <TD>2012-10-22 19:23:40</TD></TR>
  <TR class=st1>
  <TD>41</TD>
  <TD>PL</TD>
  <TD><a href=teaminfo.php?id=010871 onClick="href='teaminfo.php?id=010871'">mima</a></TD>
  <TD>301</TD>
  <TD>2013-03-15 11:30:46</TD></TR>
  <TR class=st1>
  <TD>42</TD>
  <TD>ES</TD>
  <TD><a href=teaminfo.php?id=014605 onClick="href='teaminfo.php?id=014605'">jaher</a></TD>
  <TD>300</TD>
  <TD>2010-10-27 03:31:26</TD></TR>
  <TR class=st1>
  <TD>43</TD>
  <TD>KZ</TD>
  <TD><a href=teaminfo.php?id=041737 onClick="href='teaminfo.php?id=041737'">Kolobok</a></TD>
  <TD>300</TD>
  <TD>2011-10-27 16:54:57</TD></TR>
  <TR class=st1>
  <TD>44</TD>
  <TD>BG</TD>
  <TD><a href=teaminfo.php?id=035669 onClick="href='teaminfo.php?id=035669'">Come back</a></TD>
  <TD>300</TD>
  <TD>2012-10-11 13:14:56</TD></TR>
  <TR class=st1>
  <TD>45</TD>
  <TD>PL</TD>
  <TD><a href=teaminfo.php?id=001952 onClick="href='teaminfo.php?id=001952'">PMNOX</a></TD>
  <TD>299</TD>
  <TD>2011-06-12 22:59:25</TD></TR>
  <TR class=st1>
  <TD>46</TD>
  <TD>CN</TD>
  <TD><a href=teaminfo.php?id=041720 onClick="href='teaminfo.php?id=041720'">King.Terry</a></TD>
  <TD>296</TD>
  <TD>2012-06-20 19:36:27</TD></TR>
  <TR class=st1>
  <TD>47</TD>
  <TD>PL</TD>
  <TD><a href=teaminfo.php?id=003779 onClick="href='teaminfo.php?id=003779'">monsoon</a></TD>
  <TD>296</TD>
  <TD>2013-03-28 20:51:24</TD></TR>
  <TR class=st1>
  <TD>48</TD>
  <TD>UA</TD>
  <TD><a href=teaminfo.php?id=004138 onClick="href='teaminfo.php?id=004138'">vlad89</a></TD>
  <TD>292</TD>
  <TD>2011-06-19 10:59:42</TD></TR>
  <TR class=st1>
  <TD>49</TD>
  <TD>UA</TD>
  <TD><a href=teaminfo.php?id=020025 onClick="href='teaminfo.php?id=020025'">Igor Yevchinets</a></TD>
  <TD>292</TD>
  <TD>2011-10-03 20:28:40</TD></TR>
  <TR class=st1>
  <TD>50</TD>
  <TD>IR</TD>
  <TD><a href=teaminfo.php?id=019439 onClick="href='teaminfo.php?id=019439'">Mehrdad</a></TD>
  <TD>289</TD>
  <TD>2011-07-19 11:04:26</TD></TR>
  </TABLE><a href=standing.php onClick="href='standing.php?onpage=50&page=1'")><I><B>[1]</B></I></a> <a href=standing.php onClick="href='standing.php?onpage=50&page=2'")>[2]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=3'")>[3]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=4'")>[4]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=5'")>[5]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=6'")>[6]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=7'")>[7]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=8'")>[8]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=9'")>[9]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=10'")>[10]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=11'")>[11]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=12'")>[12]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=13'")>[13]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=14'")>[14]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=15'")>[15]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=16'")>[16]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=17'")>[17]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=18'")>[18]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=19'")>[19]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=20'")>[20]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=21'")>[21]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=22'")>[22]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=23'")>[23]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=24'")>[24]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=25'")>[25]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=26'")>[26]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=27'")>[27]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=28'")>[28]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=29'")>[29]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=30'")>[30]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=31'")>[31]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=32'")>[32]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=33'")>[33]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=34'")>[34]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=35'")>[35]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=36'")>[36]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=37'")>[37]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=38'")>[38]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=39'")>[39]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=40'")>[40]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=41'")>[41]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=42'")>[42]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=43'")>[43]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=44'")>[44]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=45'")>[45]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=46'")>[46]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=47'")>[47]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=48'")>[48]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=49'")>[49]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=50'")>[50]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=51'")>[51]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=52'")>[52]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=53'")>[53]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=54'")>[54]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=55'")>[55]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=56'")>[56]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=57'")>[57]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=58'")>[58]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=59'")>[59]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=60'")>[60]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=61'")>[61]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=62'")>[62]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=63'")>[63]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=64'")>[64]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=65'")>[65]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=66'")>[66]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=67'")>[67]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=68'")>[68]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=69'")>[69]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=70'")>[70]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=71'")>[71]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=72'")>[72]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=73'")>[73]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=74'")>[74]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=75'")>[75]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=76'")>[76]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=77'")>[77]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=78'")>[78]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=79'")>[79]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=80'")>[80]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=81'")>[81]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=82'")>[82]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=83'")>[83]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=84'")>[84]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=85'")>[85]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=86'")>[86]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=87'")>[87]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=88'")>[88]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=89'")>[89]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=90'")>[90]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=91'")>[91]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=92'")>[92]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=93'")>[93]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=94'")>[94]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=95'")>[95]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=96'")>[96]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=97'")>[97]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=98'")>[98]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=99'")>[99]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=100'")>[100]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=101'")>[101]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=102'")>[102]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=103'")>[103]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=104'")>[104]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=105'")>[105]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=106'")>[106]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=107'")>[107]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=108'")>[108]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=109'")>[109]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=110'")>[110]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=111'")>[111]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=112'")>[112]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=113'")>[113]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=114'")>[114]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=115'")>[115]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=116'")>[116]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=117'")>[117]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=118'")>[118]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=119'")>[119]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=120'")>[120]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=121'")>[121]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=122'")>[122]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=123'")>[123]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=124'")>[124]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=125'")>[125]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=126'")>[126]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=127'")>[127]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=128'")>[128]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=129'")>[129]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=130'")>[130]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=131'")>[131]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=132'")>[132]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=133'")>[133]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=134'")>[134]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=135'")>[135]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=136'")>[136]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=137'")>[137]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=138'")>[138]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=139'")>[139]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=140'")>[140]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=141'")>[141]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=142'")>[142]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=143'")>[143]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=144'")>[144]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=145'")>[145]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=146'")>[146]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=147'")>[147]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=148'")>[148]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=149'")>[149]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=150'")>[150]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=151'")>[151]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=152'")>[152]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=153'")>[153]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=154'")>[154]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=155'")>[155]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=156'")>[156]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=157'")>[157]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=158'")>[158]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=159'")>[159]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=160'")>[160]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=161'")>[161]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=162'")>[162]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=163'")>[163]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=164'")>[164]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=165'")>[165]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=166'")>[166]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=167'")>[167]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=168'")>[168]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=169'")>[169]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=170'")>[170]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=171'")>[171]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=172'")>[172]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=173'")>[173]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=174'")>[174]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=175'")>[175]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=176'")>[176]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=177'")>[177]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=178'")>[178]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=179'")>[179]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=180'")>[180]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=181'")>[181]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=182'")>[182]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=183'")>[183]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=184'")>[184]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=185'")>[185]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=186'")>[186]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=187'")>[187]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=188'")>[188]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=189'")>[189]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=190'")>[190]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=191'")>[191]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=192'")>[192]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=193'")>[193]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=194'")>[194]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=195'")>[195]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=196'")>[196]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=197'")>[197]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=198'")>[198]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=199'")>[199]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=200'")>[200]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=201'")>[201]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=202'")>[202]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=203'")>[203]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=204'")>[204]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=205'")>[205]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=206'")>[206]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=207'")>[207]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=208'")>[208]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=209'")>[209]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=210'")>[210]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=211'")>[211]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=212'")>[212]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=213'")>[213]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=214'")>[214]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=215'")>[215]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=216'")>[216]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=217'")>[217]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=218'")>[218]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=219'")>[219]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=220'")>[220]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=221'")>[221]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=222'")>[222]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=223'")>[223]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=224'")>[224]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=225'")>[225]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=226'")>[226]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=227'")>[227]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=228'")>[228]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=229'")>[229]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=230'")>[230]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=231'")>[231]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=232'")>[232]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=233'")>[233]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=234'")>[234]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=235'")>[235]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=236'")>[236]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=237'")>[237]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=238'")>[238]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=239'")>[239]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=240'")>[240]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=241'")>[241]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=242'")>[242]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=243'")>[243]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=244'")>[244]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=245'")>[245]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=246'")>[246]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=247'")>[247]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=248'")>[248]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=249'")>[249]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=250'")>[250]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=251'")>[251]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=252'")>[252]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=253'")>[253]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=254'")>[254]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=255'")>[255]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=256'")>[256]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=257'")>[257]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=258'")>[258]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=259'")>[259]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=260'")>[260]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=261'")>[261]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=262'")>[262]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=263'")>[263]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=264'")>[264]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=265'")>[265]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=266'")>[266]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=267'")>[267]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=268'")>[268]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=269'")>[269]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=270'")>[270]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=271'")>[271]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=272'")>[272]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=273'")>[273]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=274'")>[274]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=275'")>[275]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=276'")>[276]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=277'")>[277]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=278'")>[278]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=279'")>[279]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=280'")>[280]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=281'")>[281]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=282'")>[282]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=283'")>[283]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=284'")>[284]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=285'")>[285]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=286'")>[286]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=287'")>[287]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=288'")>[288]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=289'")>[289]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=290'")>[290]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=291'")>[291]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=292'")>[292]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=293'")>[293]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=294'")>[294]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=295'")>[295]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=296'")>[296]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=297'")>[297]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=298'")>[298]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=299'")>[299]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=300'")>[300]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=301'")>[301]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=302'")>[302]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=303'")>[303]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=304'")>[304]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=305'")>[305]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=306'")>[306]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=307'")>[307]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=308'")>[308]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=309'")>[309]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=310'")>[310]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=311'")>[311]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=312'")>[312]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=313'")>[313]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=314'")>[314]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=315'")>[315]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=316'")>[316]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=317'")>[317]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=318'")>[318]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=319'")>[319]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=320'")>[320]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=321'")>[321]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=322'")>[322]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=323'")>[323]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=324'")>[324]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=325'")>[325]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=326'")>[326]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=327'")>[327]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=328'")>[328]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=329'")>[329]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=330'")>[330]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=331'")>[331]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=332'")>[332]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=333'")>[333]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=334'")>[334]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=335'")>[335]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=336'")>[336]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=337'")>[337]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=338'")>[338]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=339'")>[339]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=340'")>[340]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=341'")>[341]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=342'")>[342]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=343'")>[343]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=344'")>[344]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=345'")>[345]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=346'")>[346]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=347'")>[347]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=348'")>[348]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=349'")>[349]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=350'")>[350]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=351'")>[351]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=352'")>[352]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=353'")>[353]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=354'")>[354]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=355'")>[355]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=356'")>[356]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=357'")>[357]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=358'")>[358]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=359'")>[359]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=360'")>[360]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=361'")>[361]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=362'")>[362]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=363'")>[363]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=364'")>[364]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=365'")>[365]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=366'")>[366]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=367'")>[367]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=368'")>[368]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=369'")>[369]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=370'")>[370]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=371'")>[371]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=372'")>[372]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=373'")>[373]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=374'")>[374]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=375'")>[375]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=376'")>[376]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=377'")>[377]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=378'")>[378]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=379'")>[379]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=380'")>[380]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=381'")>[381]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=382'")>[382]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=383'")>[383]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=384'")>[384]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=385'")>[385]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=386'")>[386]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=387'")>[387]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=388'")>[388]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=389'")>[389]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=390'")>[390]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=391'")>[391]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=392'")>[392]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=393'")>[393]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=394'")>[394]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=395'")>[395]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=396'")>[396]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=397'")>[397]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=398'")>[398]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=399'")>[399]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=400'")>[400]</a> <a href=standing.php onClick="href='standing.php?onpage=50&page=401'")>[401]</a>   


</td></tr></table></td></tr></table><br></td> <!-- close middle colomn -->
<td width=5><img src="pixel.gif" alt="" width=5 height=1></td>
<td valign="top">
<table width=153.6 class=tb cellpadding=0 cellspacing=0><tr><td><table width=153.6 cellspacing=1 ><tr><td bgcolor=#6587B9> ::Login</td></tr><tr><td bgcolor=#FFFFFF> <style>form.login input{margin:2px;font-size:10px;}</style>    <form class=login action=login.php method=post>
    your id:<br>
    <input type=hidden name=redirect_uri value='/standing.php'>
    <input class=inp style="width: 104px; height: 18px; font-size: 10px" maxLength=16 size=5 name=try_user_id value=''>
    <br>
    password:<br>
    <input class=inp style="width: 62px; height: 18px; font-size: 10px" type=password maxLength=16 size=3 name=try_user_password value=''>
    <input type=hidden name=type_log value="login">
    <input class=frm style="width: 45px" type=submit value=Login> 
    </form>
    <a style="font-size:10px;position:relative;bottom:5px;left:2px;" href="forgot_password.php">Forgot password?</a>
    </td></tr></table></td></tr></table><br><table width=153.6 class=tb cellpadding=0 cellspacing=0><tr><td><table width=153.6 cellspacing=1 >
<tr><td bgcolor=#6587B9> ::News</td></tr><tr><td bgcolor=#FFFFFF> <b>22.10.12</b> - The problems from the Southern Subregional Programming Contest 2012 added to the problemset archive (542 - 553). <br><b>22.10.12</b> - After the start of the contest the statements in PDF will be available <a href="http://acm.sgu.ru/problems/39/problems39.pdf">by the link</a>.<br><b>23.10.11</b> - The problems from the Southern Subregional Programming Contest 2011 added to the problemset archive (530 - 541).
<br></td></tr></table></td></tr></table><br><table width=153.6 class=tb cellpadding=0 cellspacing=0><tr><td><table width=153.6 cellspacing=1 >
<tr><td bgcolor=#6587B9> ::Counter</td></tr><tr><td bgcolor=#FFFFFF> 
<table align=center>
<tr>
<td>
<!-- google -->
<script src="http://www.google-analytics.com/urchin.js" type="text/javascript">
</script>
<script type="text/javascript">
_uacct = "UA-743380-1";
urchinTracker();
</script>
<!-- SpyLOG f:0211 --> 
<script language="javascript"><!-- 
Mu="u4199.99.spylog.com";Md=document;Mnv=navigator;Mp=0; 
Md.cookie="b=b";Mc=0;if(Md.cookie)Mc=1;Mrn=Math.random(); 
Mn=(Mnv.appName.substring(0,2)=="Mi")?0:1;Mt=(new Date()).getTimezoneOffset(); 
Mz="p="+Mp+"&rn="+Mrn+"&c="+Mc+"&t="+Mt; 
if(self!=top){Mfr=1;}else{Mfr=0;}Msl="1.0"; 
//--></script><script language="javascript1.1"><!-- 
Mpl="";Msl="1.1";Mj = (Mnv.javaEnabled()?"Y":"N");Mz+='&j='+Mj; 
//--></script><script language="javascript1.2"><!-- 
Msl="1.2";Ms=screen;Mpx=(Mn==0)?Ms.colorDepth:Ms.pixelDepth; 
Mz+="&wh="+Ms.width+'x'+Ms.height+"&px="+Mpx; 
//--></script><script language="javascript1.3"><!-- 
Msl="1.3";//--></script><script language="javascript"><!-- 
My="";My+="<a href='http://"+Mu+"/cnt?cid=419999&f=3&p="+Mp+"&rn="+Mrn+"' target='_blank'>"; 
My+="<img src='http://"+Mu+"/cnt?cid=419999&"+Mz+"&sl="+Msl+"&r="+escape(Md.referrer)+"&fr="+Mfr+"&pg="+escape(window.location.href); 
My+="' border=0 width=88 height=31 alt='SpyLOG'>"; 
My+="</a>";Md.write(My);//--></script><noscript> 
<a href="http://u4199.99.spylog.com/cnt?cid=419999&f=3&p=0" target="_blank"> 
<img src="http://u4199.99.spylog.com/cnt?cid=419999&p=0" alt='SpyLOG' border='0' width=88 height=31 > 
</a></noscript> 
<!-- SpyLOG -->

</td>
</tr>
</table>

<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
var pageTracker = _gat._getTracker("UA-5412771-1");
pageTracker._trackPageview();
</script>

  </td></tr></table></td></tr></table><br></tr>
</table><table width=984 class=tb cellpadding=0 cellspacing=0><tr><td><table width=984 cellspacing=1 ><tr><td bgcolor=#FFFFFF> <table width=100% cellpadding=0 cellspacing=0 border=0><tr style='background-color : #FFFFFF;'><td align=left>Server time: 2013-11-15 16:35:36</td><td align=right><a target=_top href='mailto:acm@sgu.ru'>Online Contester</a> Team &copy; 2002 - 2013. All rights reserved.</td></tr></table></td></tr></table></td></tr></table></div></body></html>