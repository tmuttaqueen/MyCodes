<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Saratov State University :: Online Contester</title>
<META content="text/html; charset=windows-1251" http-equiv=Content-Type>
<META NAME="keywords" CONTENT="???">
<META NAME="description" CONTENT="???">
<meta name="google-site-verification" content="YvG5TvZLtlRLnK2EX22Dz815tDU7UKdDeXE_yJQp3cQ" />
<meta name="verify-v1" content="MCzwwWrZt7qOC1A2HZusdjMbXjHR+zXtTCKpx2CRSEU=" />

  <link rel="stylesheet" href="/templates.css" type="text/css">
  <link rel="stylesheet" href="/js/ui.datepicker.css" type="text/css">
  <script type="text/javascript" language="javascript" src="/js/jquery.js"></script>
  <script type="text/javascript" language="javascript" src="/js/jquery.example.js"></script>
  <script type="text/javascript" language="javascript" src="/js/ui.datepicker.js"></script>

  <link rel="stylesheet" href="templates.css" type="text/css">
  <link rel="stylesheet" href="js/ui.datepicker.css" type="text/css">
  <script type="text/javascript" language="javascript" src="js/jquery.js"></script>
  <script type="text/javascript" language="javascript" src="js/jquery.example.js"></script>
  <script type="text/javascript" language="javascript" src="js/ui.datepicker.js"></script>
<!--[if IE 6]>
<script type="text/javascript"> 
    /*Load jQuery if not already loaded*/ if(typeof jQuery == 'undefined'){ document.write("<script type=\"text/javascript\"   src=\"http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js\"></"+"script>"); var __noconflict = true; } 
    var IE6UPDATE_OPTIONS = {
        icons_path: "http://static.ie6update.com/hosted/ie6update/images/"
    }
</script>
<script type="text/javascript" src="http://static.ie6update.com/hosted/ie6update/ie6update.js"></script>
<![endif]-->
<link rel="stylesheet" href="style-1024.css" type="text/css">
</head>      <body bgcolor=#F3F6F9 text=#000000 link=#336699 vlink=#336699 alink=#336699><div align="center">
    <table width=984 class=tb cellpadding=0 cellspacing=0><tr><td><table width=984 cellspacing=1 ><tr><td bgcolor=#6587B9> <h3 align=center><font face='Geneva'><b style='color: White'>Saratov State University :: Online Contester</b></font></h3></td></tr></table></td></tr></table><br>    
<table width="974" border="0" cellpadding="0" cellspacing="0">
<tr>
<td valign="top">
<table width=153.6 class=tb cellpadding=0 cellspacing=0><tr><td><table width=153.6 cellspacing=1 ><tr><td bgcolor=#6587B9> ::Go</td></tr><tr><td bgcolor=#FFFFFF> - <a href = index.php> home </a><br>- <a href = v_avaliable.php> avaliable contests </a><br>- <a href = vdefine.php> define contest </a><br>- <a href = vdefined.php> defined contests </a><br>- <a href = problemset.php?virt=1> problemset </a><br>- <a href = submit.php?virt=1> submit </a><br>- <a href = status.php?virt=1> status </a><br>- <a href = monitor-wo-virt.php?virt=1> ranklist </a></td></tr></table></td></tr></table><br></td> <!-- close left colomn -->
<td width=5><img src="pixel.gif" alt="" width=5 height=1></td>
<td valign="top">
<table width=640 class=tb cellpadding=0 cellspacing=0><tr><td><table width=640 cellspacing=1 ><tr><td bgcolor=#6587B9> <div align=left class=dh>::define virtual contest</div></td></tr><tr><td bgcolor=#FFFFFF> <h4 style='margin:1em;'>In order to continue, you must sign in to Online Contester</h4>
</td></tr></table></td></tr></table><br></td> <!-- close middle colomn -->
<td width=5><img src="pixel.gif" alt="" width=5 height=1></td>
<td valign="top">
<table width=153.6 class=tb cellpadding=0 cellspacing=0><tr><td><table width=153.6 cellspacing=1 ><tr><td bgcolor=#6587B9> ::Login</td></tr><tr><td bgcolor=#FFFFFF> <style>form.login input{margin:2px;font-size:10px;}</style>    <form class=login action=login.php method=post>
    your id:<br>
    <input type=hidden name=redirect_uri value='/vdefined.php'>
    <input class=inp style="width: 104px; height: 18px; font-size: 10px" maxLength=16 size=5 name=try_user_id value=''>
    <br>
    password:<br>
    <input class=inp style="width: 62px; height: 18px; font-size: 10px" type=password maxLength=16 size=3 name=try_user_password value=''>
    <input type=hidden name=type_log value="login">
    <input class=frm style="width: 45px" type=submit value=Login> 
    </form>
    <a style="font-size:10px;position:relative;bottom:5px;left:2px;" href="forgot_password.php">Forgot password?</a>
    </td></tr></table></td></tr></table><br></tr>
</table><table width=984 class=tb cellpadding=0 cellspacing=0><tr><td><table width=984 cellspacing=1 ><tr><td bgcolor=#FFFFFF> <table width=100% cellpadding=0 cellspacing=0 border=0><tr style='background-color : #FFFFFF;'><td align=left>Server time: 2013-11-15 16:57:56</td><td align=right><a target=_top href='mailto:acm@sgu.ru'>Online Contester</a> Team &copy; 2002 - 2013. All rights reserved.</td></tr></table></td></tr></table></td></tr></table></div></body></html> 