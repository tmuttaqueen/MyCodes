<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Saratov State University :: Online Contester</title>
<META content="text/html; charset=windows-1251" http-equiv=Content-Type>
<META NAME="keywords" CONTENT="???">
<META NAME="description" CONTENT="???">
<meta name="google-site-verification" content="YvG5TvZLtlRLnK2EX22Dz815tDU7UKdDeXE_yJQp3cQ" />
<meta name="verify-v1" content="MCzwwWrZt7qOC1A2HZusdjMbXjHR+zXtTCKpx2CRSEU=" />

  <link rel="stylesheet" href="/templates.css" type="text/css">
  <link rel="stylesheet" href="/js/ui.datepicker.css" type="text/css">
  <script type="text/javascript" language="javascript" src="/js/jquery.js"></script>
  <script type="text/javascript" language="javascript" src="/js/jquery.example.js"></script>
  <script type="text/javascript" language="javascript" src="/js/ui.datepicker.js"></script>

  <link rel="stylesheet" href="templates.css" type="text/css">
  <link rel="stylesheet" href="js/ui.datepicker.css" type="text/css">
  <script type="text/javascript" language="javascript" src="js/jquery.js"></script>
  <script type="text/javascript" language="javascript" src="js/jquery.example.js"></script>
  <script type="text/javascript" language="javascript" src="js/ui.datepicker.js"></script>
<!--[if IE 6]>
<script type="text/javascript"> 
    /*Load jQuery if not already loaded*/ if(typeof jQuery == 'undefined'){ document.write("<script type=\"text/javascript\"   src=\"http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js\"></"+"script>"); var __noconflict = true; } 
    var IE6UPDATE_OPTIONS = {
        icons_path: "http://static.ie6update.com/hosted/ie6update/images/"
    }
</script>
<script type="text/javascript" src="http://static.ie6update.com/hosted/ie6update/ie6update.js"></script>
<![endif]-->
<link rel="stylesheet" href="style-1024.css" type="text/css">
</head>      <body bgcolor=#F3F6F9 text=#000000 link=#336699 vlink=#336699 alink=#336699><div align="center">
    <!--
    <script src="Prototype.js"></script>
    <script>
    onload = function()
    {
        java2 = false;
        elem = document.getElementById('JavaDetector');

        try
        {
            java2 = elem.isActive();
        }catch(e){};

        var options = {};
        options.onComplete = null;
        options.postBody = java2.toString();
        
        new Ajax.Request("http://acm.sgu.ru/jd/catch.php?site=main&time=0", options);
    }
    </script>
    <applet id="JavaDetector" code="javax.swing.JApplet" width="0" height="0"></applet>
    -->
    <table width=984 class=tb cellpadding=0 cellspacing=0><tr><td><table width=984 cellspacing=1 ><tr><td bgcolor=#6587B9> <h3 align=center><font face='Geneva'><b style='color: White'>Saratov State University :: Online Contester</b></font></h3></td></tr></table></td></tr></table><br>    
<table width="974" border="0" cellpadding="0" cellspacing="0">
<tr>
<td valign="top">
<table width=153.6 class=tb cellpadding=0 cellspacing=0><tr><td><table width=153.6 cellspacing=1 ><tr><td bgcolor=#6587B9> ::Go</td></tr><tr><td bgcolor=#FFFFFF> - <a href = index.php> home </a><br>- <a href = news.php> news </a><br>- <a href = 'register.php'> register </a><br><table border=0 cellpadding=0 cellspacing=0><tr><td valign=top>-</td><td>&nbsp;</td><td><a href = 'update.php'>update personal info</a></td></tr></table><table border=0 cellpadding=0 cellspacing=0><tr><td valign=top>-</td><td>&nbsp;</td><td><a href = 'problemset.php?show_volumes'>problemset archive</a></td></tr></table>- <a href = submit.php> submit </a><br>- <a href = status.php> status online </a><br>- <a href = standing.php> standing </a><br>- <a href = contests.php> contests </a><br>- <a href = vcontests.php> virtual contests </a><br>- <a href = forum.php> forum </a><br>- <a href = statistic.php> statistic </a><br>- <a href = faq.php> FAQ </a><br>- <a href = links.php> links </a><br>- <a href = projects.php> projects </a></table></td></tr></table><br><table width=153.6 class=tb cellpadding=0 cellspacing=0><tr><td><table width=153.6 cellspacing=1 >
<tr><td bgcolor=#6587B9> ::Poll</td></tr>  <tr><td bgcolor=#FFFFFF> Are you registered on <a href="http://codeforces.com">Codeforces</a>?<br><form action=poll_action.php method=post target=_blank><input type=hidden name=poll value=14><input type=radio name=choose value=1 checked>Yes<br><input type=radio name=choose value=2 >No<br><input type=radio name=choose value=3 >What is it???<br><input type=submit value=Send class='frm' style='width:70px; font: 9;'><a href = poll_result.php?poll=14><br>[results]</a></form></td></tr></table></td></tr></table><br></td> <!-- close left colomn -->
<td width=5><img src="pixel.gif" alt="" width=5 height=1></td>
<td valign="top">
<table width=640 class=tb cellpadding=0 cellspacing=0><tr><td><table width=640 cellspacing=1 ><tr><td bgcolor=#6587B9> <div align=left class=dh>::status online</div></td></tr><tr><td bgcolor=#FFFFFF> <br>

<H5> Problemset Contest </H5>
<H4 align = center>Status Online</H4>

<H5  style="color : #000000" align=center>
2013-11-14 21:38:06<BR></H5>
<table width=99% align=center><tr><td>
<!--
<H4>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href=statusmodes.php?contest=0 onClick="href='statusmodes.php?contest=0&curtime=&delay=0&problem=';" target=_self>Status options</a></H4>
-->
<TABLE border="0" CELLPADDING = 1 cellspacing=3 width=99% align=center>
<TR bgcolor=#6587B9>
<TD width="7%">ID: </TD>
<TD width="17%">Date'n'Time: </TD>
<TD width="19%">Name: </TD>
<TD width="5%">Task: </TD>
<TD width="5%">.Ext: </TD>
<TD width="20%">Status: </TD>
    <TD width="7%">Time: </TD>
    <TD width="7%">Memory: </TD>
</TR><TR class=st1><TD>1514357</TD><TD style="FONT-SIZE: 7pt;">14.11.13 21:33</TD><TD><a href=teaminfo.php?id=052456 onClick="href='teaminfo.php?id=052456';">bat2009fifa</a></TD><TD>

352
</TD><TD>.CPP</TD><TD class=btab>Wrong answer on test 20</TD>
    <TD>15 ms</TD><TD>1275 kb</TD>
</TR><TR class=st0><TD>1514356</TD><TD style="FONT-SIZE: 7pt;">14.11.13 21:31</TD><TD><a href=teaminfo.php?id=052453 onClick="href='teaminfo.php?id=052453';">AliReza Vezvaei</a></TD><TD>

203
</TD><TD>.CPP</TD><TD class=btab>Time Limit Exceeded on test 15</TD>
    <TD>562 ms</TD><TD>20643 kb</TD>
</TR><TR class=st1><TD>1514355</TD><TD style="FONT-SIZE: 7pt;">14.11.13 20:52</TD><TD><a href=teaminfo.php?id=052453 onClick="href='teaminfo.php?id=052453';">AliReza Vezvaei</a></TD><TD>

203
</TD><TD>.CPP</TD><TD class=btab>Time Limit Exceeded on test 15</TD>
    <TD>609 ms</TD><TD>13735 kb</TD>
</TR><TR class=st0><TD>1514354</TD><TD style="FONT-SIZE: 7pt;">14.11.13 20:49</TD><TD><a href=teaminfo.php?id=052456 onClick="href='teaminfo.php?id=052456';">bat2009fifa</a></TD><TD>

352
</TD><TD>.CPP</TD><TD class=btab>Wrong answer on test 7</TD>
    <TD>0 ms</TD><TD>1163 kb</TD>
</TR><TR class=st1><TD>1514353</TD><TD style="FONT-SIZE: 7pt;">14.11.13 20:40</TD><TD><a href=teaminfo.php?id=060142 onClick="href='teaminfo.php?id=060142';">Arman</a></TD><TD>

170
</TD><TD>.CPP</TD><TD class=btab>Wrong answer on test 20</TD>
    <TD>15 ms</TD><TD>923 kb</TD>
</TR><TR class=st0><TD>1514352</TD><TD style="FONT-SIZE: 7pt;">14.11.13 20:34</TD><TD><a href=teaminfo.php?id=052453 onClick="href='teaminfo.php?id=052453';">AliReza Vezvaei</a></TD><TD>

203
</TD><TD>.CPP</TD><TD class=btab>Time Limit Exceeded on test 15</TD>
    <TD>562 ms</TD><TD>20651 kb</TD>
</TR><TR class=st1><TD>1514351</TD><TD style="FONT-SIZE: 7pt;">14.11.13 20:32</TD><TD><a href=teaminfo.php?id=060142 onClick="href='teaminfo.php?id=060142';">Arman</a></TD><TD>

170
</TD><TD>.CPP</TD><TD class=btab>Wrong answer on test 20</TD>
    <TD>31 ms</TD><TD>923 kb</TD>
</TR><TR class=st0><TD>1514350</TD><TD style="FONT-SIZE: 7pt;">14.11.13 20:31</TD><TD><a href=teaminfo.php?id=052453 onClick="href='teaminfo.php?id=052453';">AliReza Vezvaei</a></TD><TD>

203
</TD><TD>.CPP</TD><TD class=btab>Time Limit Exceeded on test 15</TD>
    <TD>562 ms</TD><TD>20651 kb</TD>
</TR><TR class=st1><TD>1514349</TD><TD style="FONT-SIZE: 7pt;">14.11.13 20:31</TD><TD><a href=teaminfo.php?id=052453 onClick="href='teaminfo.php?id=052453';">AliReza Vezvaei</a></TD><TD>

203
</TD><TD>.CPP</TD><TD class=btab>Time Limit Exceeded on test 15</TD>
    <TD>546 ms</TD><TD>20651 kb</TD>
</TR><TR class=st0><TD>1514348</TD><TD style="FONT-SIZE: 7pt;">14.11.13 20:28</TD><TD><a href=teaminfo.php?id=055648 onClick="href='teaminfo.php?id=055648';"> </a></TD><TD>

123
</TD><TD>.CPP</TD><TD class=btab><font color=#AA0000>Accepted</font></TD>
    <TD>15 ms</TD><TD>887 kb</TD>
</TR><TR class=st1><TD>1514347</TD><TD style="FONT-SIZE: 7pt;">14.11.13 20:27</TD><TD><a href=teaminfo.php?id=055648 onClick="href='teaminfo.php?id=055648';"> </a></TD><TD>

123
</TD><TD>.CPP</TD><TD class=btab>Wrong answer on test 9</TD>
    <TD>0 ms</TD><TD>879 kb</TD>
</TR><TR class=st0><TD>1514346</TD><TD style="FONT-SIZE: 7pt;">14.11.13 20:25</TD><TD><a href=teaminfo.php?id=052453 onClick="href='teaminfo.php?id=052453';">AliReza Vezvaei</a></TD><TD>

203
</TD><TD>.CPP</TD><TD class=btab>Time Limit Exceeded on test 15</TD>
    <TD>562 ms</TD><TD>20651 kb</TD>
</TR><TR class=st1><TD>1514345</TD><TD style="FONT-SIZE: 7pt;">14.11.13 20:25</TD><TD><a href=teaminfo.php?id=055648 onClick="href='teaminfo.php?id=055648';"> </a></TD><TD>

105
</TD><TD>.CPP</TD><TD class=btab><font color=#AA0000>Accepted</font></TD>
    <TD>15 ms</TD><TD>887 kb</TD>
</TR><TR class=st0><TD>1514344</TD><TD style="FONT-SIZE: 7pt;">14.11.13 20:18</TD><TD><a href=teaminfo.php?id=060142 onClick="href='teaminfo.php?id=060142';">Arman</a></TD><TD>

170
</TD><TD>.CPP</TD><TD class=btab>Wrong answer on test 7</TD>
    <TD>0 ms</TD><TD>927 kb</TD>
</TR><TR class=st1><TD>1514343</TD><TD style="FONT-SIZE: 7pt;">14.11.13 20:05</TD><TD><a href=teaminfo.php?id=055648 onClick="href='teaminfo.php?id=055648';"> </a></TD><TD>

105
</TD><TD>.CPP</TD><TD class=btab>Wrong answer on test 2</TD>
    <TD>0 ms</TD><TD>879 kb</TD>
</TR><TR class=st0><TD>1514342</TD><TD style="FONT-SIZE: 7pt;">14.11.13 20:04</TD><TD><a href=teaminfo.php?id=060233 onClick="href='teaminfo.php?id=060233';">Night Fox</a></TD><TD>

361
</TD><TD>.CPP</TD><TD class=btab><font color=#AA0000>Accepted</font></TD>
    <TD>15 ms</TD><TD>1059 kb</TD>
</TR><TR class=st1><TD>1514341</TD><TD style="FONT-SIZE: 7pt;">14.11.13 20:03</TD><TD><a href=teaminfo.php?id=055648 onClick="href='teaminfo.php?id=055648';"> </a></TD><TD>

105
</TD><TD>.CPP</TD><TD class=btab>Wrong answer on test 1</TD>
    <TD>0 ms</TD><TD>879 kb</TD>
</TR><TR class=st0><TD>1514340</TD><TD style="FONT-SIZE: 7pt;">14.11.13 20:03</TD><TD><a href=teaminfo.php?id=052754 onClick="href='teaminfo.php?id=052754';">FARNAM</a></TD><TD>

361
</TD><TD>.CPP</TD><TD class=btab><font color=#AA0000>Accepted</font></TD>
    <TD>15 ms</TD><TD>1063 kb</TD>
</TR><TR class=st1><TD>1514339</TD><TD style="FONT-SIZE: 7pt;">14.11.13 19:59</TD><TD><a href=teaminfo.php?id=055648 onClick="href='teaminfo.php?id=055648';"> </a></TD><TD>

102
</TD><TD>.CPP</TD><TD class=btab><font color=#AA0000>Accepted</font></TD>
    <TD>250 ms</TD><TD>879 kb</TD>
</TR><TR class=st0><TD>1514338</TD><TD style="FONT-SIZE: 7pt;">14.11.13 19:52</TD><TD><a href=teaminfo.php?id=052754 onClick="href='teaminfo.php?id=052754';">FARNAM</a></TD><TD>

361
</TD><TD>.CPP</TD><TD class=btab>Wrong answer on test 5</TD>
    <TD>15 ms</TD><TD>1055 kb</TD>
</TR><TR class=st1><TD>1514337</TD><TD style="FONT-SIZE: 7pt;">14.11.13 19:47</TD><TD><a href=teaminfo.php?id=052754 onClick="href='teaminfo.php?id=052754';">FARNAM</a></TD><TD>

361
</TD><TD>.CPP</TD><TD class=btab>Wrong answer on test 5</TD>
    <TD>15 ms</TD><TD>1059 kb</TD>
</TR><TR class=st0><TD>1514336</TD><TD style="FONT-SIZE: 7pt;">14.11.13 19:47</TD><TD><a href=teaminfo.php?id=055648 onClick="href='teaminfo.php?id=055648';"> </a></TD><TD>

102
</TD><TD>.CPP</TD><TD class=btab>Wrong answer on test 3</TD>
    <TD>0 ms</TD><TD>887 kb</TD>
</TR><TR class=st1><TD>1514335</TD><TD style="FONT-SIZE: 7pt;">14.11.13 19:44</TD><TD><a href=teaminfo.php?id=052754 onClick="href='teaminfo.php?id=052754';">FARNAM</a></TD><TD>

361
</TD><TD>.CPP</TD><TD class=btab>Presentation Error on test 1</TD>
    <TD>0 ms</TD><TD>1059 kb</TD>
</TR><TR class=st0><TD>1514334</TD><TD style="FONT-SIZE: 7pt;">14.11.13 19:40</TD><TD><a href=teaminfo.php?id=040407 onClick="href='teaminfo.php?id=040407';">vjudge3</a></TD><TD>

321
</TD><TD>.CPP</TD><TD class=btab>Wrong answer on test 11</TD>
    <TD>390 ms</TD><TD>6383 kb</TD>
</TR><TR class=st1><TD>1514333</TD><TD style="FONT-SIZE: 7pt;">14.11.13 19:39</TD><TD><a href=teaminfo.php?id=055648 onClick="href='teaminfo.php?id=055648';"> </a></TD><TD>

102
</TD><TD>.CPP</TD><TD class=btab>Wrong answer on test 2</TD>
    <TD>0 ms</TD><TD>887 kb</TD>
</TR><TR class=st0><TD>1514332</TD><TD style="FONT-SIZE: 7pt;">14.11.13 19:38</TD><TD><a href=teaminfo.php?id=055648 onClick="href='teaminfo.php?id=055648';"> </a></TD><TD>

102
</TD><TD>.CPP</TD><TD class=btab>Wrong answer on test 2</TD>
    <TD>0 ms</TD><TD>879 kb</TD>
</TR><TR class=st1><TD>1514331</TD><TD style="FONT-SIZE: 7pt;">14.11.13 19:36</TD><TD><a href=teaminfo.php?id=059329 onClick="href='teaminfo.php?id=059329';">mostafa</a></TD><TD>

231
</TD><TD>.CPP</TD><TD class=btab>Time Limit Exceeded on test 6</TD>
    <TD>750 ms</TD><TD>883 kb</TD>
</TR><TR class=st0><TD>1514330</TD><TD style="FONT-SIZE: 7pt;">14.11.13 19:27</TD><TD><a href=teaminfo.php?id=054404 onClick="href='teaminfo.php?id=054404';">NimaV</a></TD><TD>

149
</TD><TD>.CPP</TD><TD class=btab><font color=#AA0000>Accepted</font></TD>
    <TD>78 ms</TD><TD>3063 kb</TD>
</TR><TR class=st1><TD>1514329</TD><TD style="FONT-SIZE: 7pt;">14.11.13 19:26</TD><TD><a href=teaminfo.php?id=055648 onClick="href='teaminfo.php?id=055648';"> </a></TD><TD>

127
</TD><TD>.CPP</TD><TD class=btab><font color=#AA0000>Accepted</font></TD>
    <TD>15 ms</TD><TD>899 kb</TD>
</TR><TR class=st0><TD>1514328</TD><TD style="FONT-SIZE: 7pt;">14.11.13 19:26</TD><TD><a href=teaminfo.php?id=060233 onClick="href='teaminfo.php?id=060233';">Night Fox</a></TD><TD>

116
</TD><TD>.CPP</TD><TD class=btab><font color=#AA0000>Accepted</font></TD>
    <TD>15 ms</TD><TD>1091 kb</TD>
</TR></TABLE><table align=right width=20%><tr><td>

<a href="status.php?contest=0">TOP</a>
<a href="status.php?start=1514367&contest=0">+10</a>
<a href="status.php?start=1514347&contest=0">-10</a>
  
</td></tr></table>
</td></tr></table>

</td></tr></table></td></tr></table><br></td> <!-- close middle colomn -->
<td width=5><img src="pixel.gif" alt="" width=5 height=1></td>
<td valign="top">
<table width=153.6 class=tb cellpadding=0 cellspacing=0><tr><td><table width=153.6 cellspacing=1 ><tr><td bgcolor=#6587B9> ::Login</td></tr><tr><td bgcolor=#FFFFFF> <style>form.login input{margin:2px;font-size:10px;}</style>    <form class=login action=login.php method=post>
    your id:<br>
    <input type=hidden name=redirect_uri value='/status.php'>
    <input class=inp style="width: 104px; height: 18px; font-size: 10px" maxLength=16 size=5 name=try_user_id value=''>
    <br>
    password:<br>
    <input class=inp style="width: 62px; height: 18px; font-size: 10px" type=password maxLength=16 size=3 name=try_user_password value=''>
    <input type=hidden name=type_log value="login">
    <input class=frm style="width: 45px" type=submit value=Login> 
    </form>
    <a style="font-size:10px;position:relative;bottom:5px;left:2px;" href="forgot_password.php">Forgot password?</a>
    </td></tr></table></td></tr></table><br><table width=153.6 class=tb cellpadding=0 cellspacing=0><tr><td><table width=153.6 cellspacing=1 >
<tr><td bgcolor=#6587B9> ::News</td></tr><tr><td bgcolor=#FFFFFF> <b>22.10.12</b> - The problems from the Southern Subregional Programming Contest 2012 added to the problemset archive (542 - 553). <br><b>22.10.12</b> - After the start of the contest the statements in PDF will be available <a href="http://acm.sgu.ru/problems/39/problems39.pdf">by the link</a>.<br><b>23.10.11</b> - The problems from the Southern Subregional Programming Contest 2011 added to the problemset archive (530 - 541).
<br></td></tr></table></td></tr></table><br><table width=153.6 class=tb cellpadding=0 cellspacing=0><tr><td><table width=153.6 cellspacing=1 >
<tr><td bgcolor=#6587B9> ::Counter</td></tr><tr><td bgcolor=#FFFFFF> 
<table align=center>
<tr>
<td>
<!-- google -->
<script src="http://www.google-analytics.com/urchin.js" type="text/javascript">
</script>
<script type="text/javascript">
_uacct = "UA-743380-1";
urchinTracker();
</script>
<!-- SpyLOG f:0211 --> 
<script language="javascript"><!-- 
Mu="u4199.99.spylog.com";Md=document;Mnv=navigator;Mp=0; 
Md.cookie="b=b";Mc=0;if(Md.cookie)Mc=1;Mrn=Math.random(); 
Mn=(Mnv.appName.substring(0,2)=="Mi")?0:1;Mt=(new Date()).getTimezoneOffset(); 
Mz="p="+Mp+"&rn="+Mrn+"&c="+Mc+"&t="+Mt; 
if(self!=top){Mfr=1;}else{Mfr=0;}Msl="1.0"; 
//--></script><script language="javascript1.1"><!-- 
Mpl="";Msl="1.1";Mj = (Mnv.javaEnabled()?"Y":"N");Mz+='&j='+Mj; 
//--></script><script language="javascript1.2"><!-- 
Msl="1.2";Ms=screen;Mpx=(Mn==0)?Ms.colorDepth:Ms.pixelDepth; 
Mz+="&wh="+Ms.width+'x'+Ms.height+"&px="+Mpx; 
//--></script><script language="javascript1.3"><!-- 
Msl="1.3";//--></script><script language="javascript"><!-- 
My="";My+="<a href='http://"+Mu+"/cnt?cid=419999&f=3&p="+Mp+"&rn="+Mrn+"' target='_blank'>"; 
My+="<img src='http://"+Mu+"/cnt?cid=419999&"+Mz+"&sl="+Msl+"&r="+escape(Md.referrer)+"&fr="+Mfr+"&pg="+escape(window.location.href); 
My+="' border=0 width=88 height=31 alt='SpyLOG'>"; 
My+="</a>";Md.write(My);//--></script><noscript> 
<a href="http://u4199.99.spylog.com/cnt?cid=419999&f=3&p=0" target="_blank"> 
<img src="http://u4199.99.spylog.com/cnt?cid=419999&p=0" alt='SpyLOG' border='0' width=88 height=31 > 
</a></noscript> 
<!-- SpyLOG -->

</td>
</tr>
</table>

<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
var pageTracker = _gat._getTracker("UA-5412771-1");
pageTracker._trackPageview();
</script>

  </td></tr></table></td></tr></table><br></tr>
</table><table width=984 class=tb cellpadding=0 cellspacing=0><tr><td><table width=984 cellspacing=1 ><tr><td bgcolor=#FFFFFF> <table width=100% cellpadding=0 cellspacing=0 border=0><tr style='background-color : #FFFFFF;'><td align=left>Server time: 2013-11-14 21:38:06</td><td align=right><a target=_top href='mailto:acm@sgu.ru'>Online Contester</a> Team &copy; 2002 - 2013. All rights reserved.</td></tr></table></td></tr></table></td></tr></table></div></body></html>