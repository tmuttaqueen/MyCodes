<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Saratov State University :: Online Contester</title>
<META content="text/html; charset=windows-1251" http-equiv=Content-Type>
<META NAME="keywords" CONTENT="???">
<META NAME="description" CONTENT="???">
<meta name="google-site-verification" content="YvG5TvZLtlRLnK2EX22Dz815tDU7UKdDeXE_yJQp3cQ" />
<meta name="verify-v1" content="MCzwwWrZt7qOC1A2HZusdjMbXjHR+zXtTCKpx2CRSEU=" />

  <link rel="stylesheet" href="/templates.css" type="text/css">
  <link rel="stylesheet" href="/js/ui.datepicker.css" type="text/css">
  <script type="text/javascript" language="javascript" src="/js/jquery.js"></script>
  <script type="text/javascript" language="javascript" src="/js/jquery.example.js"></script>
  <script type="text/javascript" language="javascript" src="/js/ui.datepicker.js"></script>

  <link rel="stylesheet" href="templates.css" type="text/css">
  <link rel="stylesheet" href="js/ui.datepicker.css" type="text/css">
  <script type="text/javascript" language="javascript" src="js/jquery.js"></script>
  <script type="text/javascript" language="javascript" src="js/jquery.example.js"></script>
  <script type="text/javascript" language="javascript" src="js/ui.datepicker.js"></script>
<!--[if IE 6]>
<script type="text/javascript"> 
    /*Load jQuery if not already loaded*/ if(typeof jQuery == 'undefined'){ document.write("<script type=\"text/javascript\"   src=\"http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js\"></"+"script>"); var __noconflict = true; } 
    var IE6UPDATE_OPTIONS = {
        icons_path: "http://static.ie6update.com/hosted/ie6update/images/"
    }
</script>
<script type="text/javascript" src="http://static.ie6update.com/hosted/ie6update/ie6update.js"></script>
<![endif]-->
<link rel="stylesheet" href="style-1024.css" type="text/css">
</head>      <body bgcolor=#F3F6F9 text=#000000 link=#336699 vlink=#336699 alink=#336699><div align="center">
    <table width=984 class=tb cellpadding=0 cellspacing=0><tr><td><table width=984 cellspacing=1 ><tr><td bgcolor=#6587B9> <h3 align=center><font face='Geneva'><b style='color: White'>Saratov State University :: Online Contester</b></font></h3></td></tr></table></td></tr></table><br>    
<table width="974" border="0" cellpadding="0" cellspacing="0">
<tr>
<td valign="top">
<table width=153.6 class=tb cellpadding=0 cellspacing=0><tr><td><table width=153.6 cellspacing=1 ><tr><td bgcolor=#6587B9> ::Go</td></tr><tr><td bgcolor=#FFFFFF> - <a href = index.php> home </a><br>- <a href = news.php> news </a><br>- <a href = 'register.php'> register </a><br><table border=0 cellpadding=0 cellspacing=0><tr><td valign=top>-</td><td>&nbsp;</td><td><a href = 'update.php'>update personal info</a></td></tr></table><table border=0 cellpadding=0 cellspacing=0><tr><td valign=top>-</td><td>&nbsp;</td><td><a href = 'problemset.php?show_volumes'>problemset archive</a></td></tr></table>- <a href = submit.php> submit </a><br>- <a href = status.php> status online </a><br>- <a href = standing.php> standing </a><br>- <a href = contests.php> contests </a><br>- <a href = vcontests.php> virtual contests </a><br>- <a href = forum.php> forum </a><br>- <a href = statistic.php> statistic </a><br>- <a href = faq.php> FAQ </a><br>- <a href = links.php> links </a><br>- <a href = projects.php> projects </a></table></td></tr></table><br><table width=153.6 class=tb cellpadding=0 cellspacing=0><tr><td><table width=153.6 cellspacing=1 >
<tr><td bgcolor=#6587B9> ::Poll</td></tr>  <tr><td bgcolor=#FFFFFF> Are you registered on <a href="http://codeforces.com">Codeforces</a>?<br><form action=poll_action.php method=post target=_blank><input type=hidden name=poll value=14><input type=radio name=choose value=1 checked>Yes<br><input type=radio name=choose value=2 >No<br><input type=radio name=choose value=3 >What is it???<br><input type=submit value=Send class='frm' style='width:70px; font: 9;'><a href = poll_result.php?poll=14><br>[results]</a></form></td></tr></table></td></tr></table><br></td> <!-- close left colomn -->
<td width=5><img src="pixel.gif" alt="" width=5 height=1></td>
<td valign="top">
<table width=640 class=tb cellpadding=0 cellspacing=0><tr><td><table width=640 cellspacing=1 ><tr><td bgcolor=#6587B9> <div align=left class=dh>::statistics</div></td></tr><tr><td bgcolor=#FFFFFF> 
<br><h5 align=right>Statistic was build for period since 2013-11-12 00:00:00</h5>
<table width=90% align=center>

<tr> <td> 
  <h4 align = center> Top Ten </h4>
</td> </tr>
<tr> <td> 

<TABLE  border="0" CELLPADDING = 4  width=99% align=center>
<TR bgcolor=#6587B9>
<TD width="8%">Rank: </TD>
<TD width="8%">Land: </TD>
<TD width="35%">ID: </TD>
<TD width="5%">AC: </TD>
<TD width="25%">Last Accepted: </TD>
</TR>
<TR class=
  st0>
  <TD>1</TD>
  <TD>CN</TD>
  <TD><a href=teaminfo.php?id=060021>rong</a></TD>
  <TD>12</TD>
  <TD>2013-11-14 18:04:23</TD></TR>
  <TR class=
  st1>
  <TD>2</TD>
  <TD>IR</TD>
  <TD><a href=teaminfo.php?id=060233>Night Fox</a></TD>
  <TD>12</TD>
  <TD>2013-11-14 20:04:45</TD></TR>
  <TR class=
  st0>
  <TD>3</TD>
  <TD>IR</TD>
  <TD><a href=teaminfo.php?id=060265>Alireza Shafiee</a></TD>
  <TD>8</TD>
  <TD>2013-11-13 12:27:20</TD></TR>
  <TR class=
  st1>
  <TD>4</TD>
  <TD>CN</TD>
  <TD><a href=teaminfo.php?id=059647>qian99</a></TD>
  <TD>8</TD>
  <TD>2013-11-13 15:52:36</TD></TR>
  <TR class=
  st0>
  <TD>5</TD>
  <TD>CN</TD>
  <TD><a href=teaminfo.php?id=053635>Kevin Tan</a></TD>
  <TD>8</TD>
  <TD>2013-11-14 17:42:47</TD></TR>
  <TR class=
  st1>
  <TD>6</TD>
  <TD>IR</TD>
  <TD><a href=teaminfo.php?id=058451>peyman.j</a></TD>
  <TD>8</TD>
  <TD>2013-11-14 18:15:14</TD></TR>
  <TR class=
  st0>
  <TD>7</TD>
  <TD>IR</TD>
  <TD><a href=teaminfo.php?id=057716>Alireza514</a></TD>
  <TD>7</TD>
  <TD>2013-11-14 19:11:05</TD></TR>
  <TR class=
  st1>
  <TD>8</TD>
  <TD>IR</TD>
  <TD><a href=teaminfo.php?id=054404>NimaV</a></TD>
  <TD>7</TD>
  <TD>2013-11-14 19:27:34</TD></TR>
  <TR class=
  st0>
  <TD>9</TD>
  <TD>CN</TD>
  <TD><a href=teaminfo.php?id=060257>caicao</a></TD>
  <TD>6</TD>
  <TD>2013-11-13 14:08:30</TD></TR>
  <TR class=
  st1>
  <TD>10</TD>
  <TD>CN</TD>
  <TD><a href=teaminfo.php?id=060172>iCrany</a></TD>
  <TD>6</TD>
  <TD>2013-11-14 14:52:25</TD></TR>
  </TABLE>
</td> </tr> 

</table>
<br><table width=90% align=center>

<tr> <td> 
  <h4 align = center> Countries Top Ten </h4>
</td> </tr>
<tr> <td> 

<TABLE  border="0" CELLPADDING = 4  width=99% align=center>
<TR bgcolor=#6587B9>
<TD width="05%">Rank: </TD>
<TD width="30%">Country: </TD>
<TD width="5%">AC: </TD>
<TD width="25%">Country hero: </TD>
<TD width="10%">Hero's Accepted: </TD>
</TR>
<TR class=
  st0>
  <TD>1</TD>
  <TD>IRAN (ISLAMIC REPUBLIC OF)</TD>
  <TD>118</TD>
    <TD><a href=teaminfo.php?id=060233>Night Fox</a></TD>
  <TD>12</TD>
  </TR>
  <TR class=
  st1>
  <TD>2</TD>
  <TD>CHINA</TD>
  <TD>73</TD>
    <TD><a href=teaminfo.php?id=060021>rong</a></TD>
  <TD>12</TD>
  </TR>
  <TR class=
  st0>
  <TD>3</TD>
  <TD>UZBEKISTAN</TD>
  <TD>7</TD>
    <TD><a href=teaminfo.php?id=053786>Somebody 9</a></TD>
  <TD>3</TD>
  </TR>
  <TR class=
  st1>
  <TD>4</TD>
  <TD>UNITED STATES</TD>
  <TD>3</TD>
    <TD><a href=teaminfo.php?id=058187>iwantcombo</a></TD>
  <TD>1</TD>
  </TR>
  <TR class=
  st0>
  <TD>5</TD>
  <TD>BANGLADESH</TD>
  <TD>2</TD>
    <TD><a href=teaminfo.php?id=050175>Woodpecker</a></TD>
  <TD>1</TD>
  </TR>
  <TR class=
  st1>
  <TD>6</TD>
  <TD>RUSSIAN FEDERATION</TD>
  <TD>2</TD>
    <TD><a href=teaminfo.php?id=060202>rumyancev-vala</a></TD>
  <TD>1</TD>
  </TR>
  <TR class=
  st0>
  <TD>7</TD>
  <TD>KOREA, REPUBLIC OF</TD>
  <TD>1</TD>
    <TD><a href=teaminfo.php?id=034895>unbing</a></TD>
  <TD>1</TD>
  </TR>
  <TR class=
  st1>
  <TD>8</TD>
  <TD>DENMARK</TD>
  <TD>1</TD>
    <TD><a href=teaminfo.php?id=059714>chris</a></TD>
  <TD>1</TD>
  </TR>
  <TR class=
  st0>
  <TD>9</TD>
  <TD>AUSTRALIA</TD>
  <TD>1</TD>
    <TD><a href=teaminfo.php?id=060268>koksul</a></TD>
  <TD>1</TD>
  </TR>
  <TR class=
  st1>
  <TD>10</TD>
  <TD>VIET NAM</TD>
  <TD>1</TD>
    <TD><a href=teaminfo.php?id=058938>toilanvd</a></TD>
  <TD>1</TD>
  </TR>
  </TABLE>
</td> </tr> 

</table>
<br><table width=90% align=center>

<tr> <td> 
  <h4 align = center> Summary for contests top ten (all online contests)</h4>
</td> </tr>
<tr> <td> 

<TABLE  border="0" CELLPADDING = 4  width=99% align=center>
<TR bgcolor=#6587B9>
<TD width="5%">Rank: </TD>
<TD width="10%">ID: </TD>
<TD width="10%">Country: </TD>
<TD width="30%">Name: </TD>
<TD width="10%">AC: </TD>
</TR>
<TR class=
  st0>
  <TD>1</TD>
  <TD>002135</TD>
  <TD>CN</TD>
  <TD><a href=teaminfo.php?id=002135>Tiancheng LOU</a></TD>
  <TD>129</TD></TR>
  <TR class=
  st1>
  <TD>2</TD>
  <TD>018947</TD>
  <TD>UA</TD>
  <TD><a href=teaminfo.php?id=018947>Anton Lunyov</a></TD>
  <TD>70</TD></TR>
  <TR class=
  st0>
  <TD>3</TD>
  <TD>003852</TD>
  <TD>BY</TD>
  <TD><a href=teaminfo.php?id=003852>Gennady Korotkevich</a></TD>
  <TD>65</TD></TR>
  <TR class=
  st1>
  <TD>4</TD>
  <TD>016469</TD>
  <TD>IR</TD>
  <TD><a href=teaminfo.php?id=016469>PMP Forever</a></TD>
  <TD>56</TD></TR>
  <TR class=
  st0>
  <TD>5</TD>
  <TD>000176</TD>
  <TD>RU</TD>
  <TD><a href=teaminfo.php?id=000176>rem</a></TD>
  <TD>55</TD></TR>
  <TR class=
  st1>
  <TD>6</TD>
  <TD>002331</TD>
  <TD>RU</TD>
  <TD><a href=teaminfo.php?id=002331>USU Team</a></TD>
  <TD>45</TD></TR>
  <TR class=
  st0>
  <TD>7</TD>
  <TD>000370</TD>
  <TD>RU</TD>
  <TD><a href=teaminfo.php?id=000370>Gassa</a></TD>
  <TD>44</TD></TR>
  <TR class=
  st1>
  <TD>8</TD>
  <TD>012315</TD>
  <TD>CN</TD>
  <TD><a href=teaminfo.php?id=012315>qzc52</a></TD>
  <TD>43</TD></TR>
  <TR class=
  st0>
  <TD>9</TD>
  <TD>016483</TD>
  <TD>UA</TD>
  <TD><a href=teaminfo.php?id=016483>Vasyl</a></TD>
  <TD>43</TD></TR>
  <TR class=
  st1>
  <TD>10</TD>
  <TD>001603</TD>
  <TD>RU</TD>
  <TD><a href=teaminfo.php?id=001603>SPb ETU 2</a></TD>
  <TD>40</TD></TR>
  </TABLE>
</td> </tr> 

</table>
<br><table width=90% align=center>

<tr> <td> 
  <h4 align = center> Submits statistic </h4>
</td> </tr>
<tr> <td> 

<TABLE  border="0" CELLPADDING = 4  width=99% align=center>
<TR bgcolor=#6587B9>
<TD width="5%">AC: </TD>
<TD width="5%">WA: </TD>
<TD width="5%">TL: </TD>
<TD width="5%">PE: </TD>
<TD width="5%">CE: </TD>
<TD width="5%">RE: </TD>
<TD width="5%">ML: </TD>
<TD width="5%">Other: </TD>
</TR>

<tr class=st1><td>271</td><td>453</td><td>114</td><td>35</td><td>42</td><td>40</td><td>47</td><td>1</td></tr></table>
</td> </tr>
</table>
<br><table width=90% align=center>

<tr> <td colspan = 2> 
  <h4 align = center> Find user </h4>
</td> </tr>
<tr><td align>
<form action=find.php method=post>
<input class=inp name=find_id>
<br>
<input class=frm value=" find " type=submit>
</td> 
<td valign=top>
You can use '*' and '?' symbols
</form>
</td>
</tr>
</table>
<br>
</td></tr></table></td></tr></table><br></td> <!-- close middle colomn -->
<td width=5><img src="pixel.gif" alt="" width=5 height=1></td>
<td valign="top">
<table width=153.6 class=tb cellpadding=0 cellspacing=0><tr><td><table width=153.6 cellspacing=1 ><tr><td bgcolor=#6587B9> ::Login</td></tr><tr><td bgcolor=#FFFFFF> <style>form.login input{margin:2px;font-size:10px;}</style>    <form class=login action=login.php method=post>
    your id:<br>
    <input type=hidden name=redirect_uri value='/statistic.php'>
    <input class=inp style="width: 104px; height: 18px; font-size: 10px" maxLength=16 size=5 name=try_user_id value=''>
    <br>
    password:<br>
    <input class=inp style="width: 62px; height: 18px; font-size: 10px" type=password maxLength=16 size=3 name=try_user_password value=''>
    <input type=hidden name=type_log value="login">
    <input class=frm style="width: 45px" type=submit value=Login> 
    </form>
    <a style="font-size:10px;position:relative;bottom:5px;left:2px;" href="forgot_password.php">Forgot password?</a>
    </td></tr></table></td></tr></table><br><table width=153.6 class=tb cellpadding=0 cellspacing=0><tr><td><table width=153.6 cellspacing=1 >
<tr><td bgcolor=#6587B9> ::News</td></tr><tr><td bgcolor=#FFFFFF> <b>22.10.12</b> - The problems from the Southern Subregional Programming Contest 2012 added to the problemset archive (542 - 553). <br><b>22.10.12</b> - After the start of the contest the statements in PDF will be available <a href="http://acm.sgu.ru/problems/39/problems39.pdf">by the link</a>.<br><b>23.10.11</b> - The problems from the Southern Subregional Programming Contest 2011 added to the problemset archive (530 - 541).
<br></td></tr></table></td></tr></table><br><table width=153.6 class=tb cellpadding=0 cellspacing=0><tr><td><table width=153.6 cellspacing=1 >
<tr><td bgcolor=#6587B9> ::Counter</td></tr><tr><td bgcolor=#FFFFFF> 
<table align=center>
<tr>
<td>
<!-- google -->
<script src="http://www.google-analytics.com/urchin.js" type="text/javascript">
</script>
<script type="text/javascript">
_uacct = "UA-743380-1";
urchinTracker();
</script>
<!-- SpyLOG f:0211 --> 
<script language="javascript"><!-- 
Mu="u4199.99.spylog.com";Md=document;Mnv=navigator;Mp=0; 
Md.cookie="b=b";Mc=0;if(Md.cookie)Mc=1;Mrn=Math.random(); 
Mn=(Mnv.appName.substring(0,2)=="Mi")?0:1;Mt=(new Date()).getTimezoneOffset(); 
Mz="p="+Mp+"&rn="+Mrn+"&c="+Mc+"&t="+Mt; 
if(self!=top){Mfr=1;}else{Mfr=0;}Msl="1.0"; 
//--></script><script language="javascript1.1"><!-- 
Mpl="";Msl="1.1";Mj = (Mnv.javaEnabled()?"Y":"N");Mz+='&j='+Mj; 
//--></script><script language="javascript1.2"><!-- 
Msl="1.2";Ms=screen;Mpx=(Mn==0)?Ms.colorDepth:Ms.pixelDepth; 
Mz+="&wh="+Ms.width+'x'+Ms.height+"&px="+Mpx; 
//--></script><script language="javascript1.3"><!-- 
Msl="1.3";//--></script><script language="javascript"><!-- 
My="";My+="<a href='http://"+Mu+"/cnt?cid=419999&f=3&p="+Mp+"&rn="+Mrn+"' target='_blank'>"; 
My+="<img src='http://"+Mu+"/cnt?cid=419999&"+Mz+"&sl="+Msl+"&r="+escape(Md.referrer)+"&fr="+Mfr+"&pg="+escape(window.location.href); 
My+="' border=0 width=88 height=31 alt='SpyLOG'>"; 
My+="</a>";Md.write(My);//--></script><noscript> 
<a href="http://u4199.99.spylog.com/cnt?cid=419999&f=3&p=0" target="_blank"> 
<img src="http://u4199.99.spylog.com/cnt?cid=419999&p=0" alt='SpyLOG' border='0' width=88 height=31 > 
</a></noscript> 
<!-- SpyLOG -->

</td>
</tr>
</table>

<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
var pageTracker = _gat._getTracker("UA-5412771-1");
pageTracker._trackPageview();
</script>

  </td></tr></table></td></tr></table><br></tr>
</table><table width=984 class=tb cellpadding=0 cellspacing=0><tr><td><table width=984 cellspacing=1 ><tr><td bgcolor=#FFFFFF> <table width=100% cellpadding=0 cellspacing=0 border=0><tr style='background-color : #FFFFFF;'><td align=left>Server time: 2013-11-14 21:38:14</td><td align=right><a target=_top href='mailto:acm@sgu.ru'>Online Contester</a> Team &copy; 2002 - 2013. All rights reserved.</td></tr></table></td></tr></table></td></tr></table></div></body></html>