<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Saratov State University :: Online Contester</title>
<META content="text/html; charset=windows-1251" http-equiv=Content-Type>
<META NAME="keywords" CONTENT="???">
<META NAME="description" CONTENT="???">
<meta name="google-site-verification" content="YvG5TvZLtlRLnK2EX22Dz815tDU7UKdDeXE_yJQp3cQ" />
<meta name="verify-v1" content="MCzwwWrZt7qOC1A2HZusdjMbXjHR+zXtTCKpx2CRSEU=" />

  <link rel="stylesheet" href="/templates.css" type="text/css">
  <link rel="stylesheet" href="/js/ui.datepicker.css" type="text/css">
  <script type="text/javascript" language="javascript" src="/js/jquery.js"></script>
  <script type="text/javascript" language="javascript" src="/js/jquery.example.js"></script>
  <script type="text/javascript" language="javascript" src="/js/ui.datepicker.js"></script>

  <link rel="stylesheet" href="templates.css" type="text/css">
  <link rel="stylesheet" href="js/ui.datepicker.css" type="text/css">
  <script type="text/javascript" language="javascript" src="js/jquery.js"></script>
  <script type="text/javascript" language="javascript" src="js/jquery.example.js"></script>
  <script type="text/javascript" language="javascript" src="js/ui.datepicker.js"></script>
<!--[if IE 6]>
<script type="text/javascript"> 
    /*Load jQuery if not already loaded*/ if(typeof jQuery == 'undefined'){ document.write("<script type=\"text/javascript\"   src=\"http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js\"></"+"script>"); var __noconflict = true; } 
    var IE6UPDATE_OPTIONS = {
        icons_path: "http://static.ie6update.com/hosted/ie6update/images/"
    }
</script>
<script type="text/javascript" src="http://static.ie6update.com/hosted/ie6update/ie6update.js"></script>
<![endif]-->
<link rel="stylesheet" href="style-1024.css" type="text/css">
</head>      <body bgcolor=#F3F6F9 text=#000000 link=#336699 vlink=#336699 alink=#336699><div align="center">
    <table width=984 class=tb cellpadding=0 cellspacing=0><tr><td><table width=984 cellspacing=1 ><tr><td bgcolor=#6587B9> <h3 align=center><font face='Geneva'><b style='color: White'>Saratov State University :: Online Contester</b></font></h3></td></tr></table></td></tr></table><br>    
<table width="974" border="0" cellpadding="0" cellspacing="0">
<tr>
<td valign="top">
<table width=153.6 class=tb cellpadding=0 cellspacing=0><tr><td><table width=153.6 cellspacing=1 ><tr><td bgcolor=#6587B9> ::Go</td></tr><tr><td bgcolor=#FFFFFF> - <a href = index.php> home </a><br>- <a href = news.php> news </a><br>- <a href = 'register.php'> register </a><br><table border=0 cellpadding=0 cellspacing=0><tr><td valign=top>-</td><td>&nbsp;</td><td><a href = 'update.php'>update personal info</a></td></tr></table><table border=0 cellpadding=0 cellspacing=0><tr><td valign=top>-</td><td>&nbsp;</td><td><a href = 'problemset.php?show_volumes'>problemset archive</a></td></tr></table>- <a href = submit.php> submit </a><br>- <a href = status.php> status online </a><br>- <a href = standing.php> standing </a><br>- <a href = contests.php> contests </a><br>- <a href = vcontests.php> virtual contests </a><br>- <a href = forum.php> forum </a><br>- <a href = statistic.php> statistic </a><br>- <a href = faq.php> FAQ </a><br>- <a href = links.php> links </a><br>- <a href = projects.php> projects </a></table></td></tr></table><br><table width=153.6 class=tb cellpadding=0 cellspacing=0><tr><td><table width=153.6 cellspacing=1 >
<tr><td bgcolor=#6587B9> ::Poll</td></tr>  <tr><td bgcolor=#FFFFFF> Are you registered on <a href="http://codeforces.com">Codeforces</a>?<br><form action=poll_action.php method=post target=_blank><input type=hidden name=poll value=14><input type=radio name=choose value=1 checked>Yes<br><input type=radio name=choose value=2 >No<br><input type=radio name=choose value=3 >What is it???<br><input type=submit value=Send class='frm' style='width:70px; font: 9;'><a href = poll_result.php?poll=14><br>[results]</a></form></td></tr></table></td></tr></table><br></td> <!-- close left colomn -->
<td width=5><img src="pixel.gif" alt="" width=5 height=1></td>
<td valign="top">
<table width=640 class=tb cellpadding=0 cellspacing=0><tr><td><table width=640 cellspacing=1 ><tr><td bgcolor=#6587B9> <div align=left class=dh>::news</div></td></tr><tr><td bgcolor=#FFFFFF> <table><tr><td valign=top nowrap><b><br></b></td><td></td></tr><tr><td valign=top nowrap><b>22.10.12</b> - </td><td>The problems from the Southern Subregional Programming Contest 2012 added to the problemset archive (542 - 553). </td></tr><tr><td valign=top nowrap><b><br></b></td><td></td></tr><tr><td valign=top nowrap><b>22.10.12</b> - </td><td>After the start of the contest the statements in PDF will be available <a href="http://acm.sgu.ru/problems/39/problems39.pdf">by the link</a>.</td></tr><tr><td valign=top nowrap><b><br></b></td><td></td></tr><tr><td valign=top nowrap><b>23.10.11</b> - </td><td>The problems from the Southern Subregional Programming Contest 2011 added to the problemset archive (530 - 541).
</td></tr><tr><td valign=top nowrap><b><br></b></td><td></td></tr><tr><td valign=top nowrap><b>23.10.11</b> - </td><td>After the start of the contest the statements in PDF will be available <a href="http://acm.sgu.ru/problems/38/problems38.pdf">by the link</a>.</td></tr><tr><td valign=top nowrap><b><br></b></td><td></td></tr><tr><td valign=top nowrap><b>03.07.11</b> - </td><td>All java submissions made since 17 June have been retested. There was a problem with incorrect measuring of consumed memory for java programs.</td></tr><tr><td valign=top nowrap><b><br></b></td><td></td></tr><tr><td valign=top nowrap><b>16.06.11</b> - </td><td>Server now uses new machine for testing: <b>Intel Core 2 Duo 2.66 GHz 3Gb RAM</b>. Time limits for all problems have been changed. Running times of all submissions have been approximately recalculated.</td></tr><tr><td valign=top nowrap><b><br></b></td><td></td></tr><tr><td valign=top nowrap><b>03.04.11</b> - </td><td><b>Attention!</b>
Infrastructure of the site is moving to another server. All submissions made from 22:00 on April 3 to the end of works will be lost. Tentative completion date of moving process - April 5.</td></tr><tr><td valign=top nowrap><b><br></b></td><td></td></tr><tr><td valign=top nowrap><b>23.10.10</b> - </td><td>The problemset for "Southern Subregional Programming Contest 2010" is <a href="problems/37/problems37.pdf">available as PDF</a>.</td></tr><tr><td valign=top nowrap><b><br></b></td><td></td></tr><tr><td valign=top nowrap><b>01.02.10</b> - </td><td>We would like to introduce a programming competition portal <a href="http://codeforces.com">Codeforces</a> (and <a href="http://codeforces.ru">russian version</a>).</td></tr><tr><td valign=top nowrap><b><br></b></td><td></td></tr><tr><td valign=top nowrap><b>27.12.09</b> - </td><td>The problemset for "Petr Mitrichev Contest 6" is <a href="problems/36/problems36.pdf">available as PDF</a>.
<div style="display:none;">amir</div></td></tr><tr><td valign=top nowrap><b><br></b></td><td></td></tr><tr><td valign=top nowrap><b>20.12.09</b> - </td><td>The problemset for "Petr Mitrichev Contest 5" is
<a href="problems/35/problems35.pdf">available as PDF</a>.</td></tr><tr><td valign=top nowrap><b><br></b></td><td></td></tr><tr><td valign=top nowrap><b>07.11.09</b> - </td><td>We are sorry to report this, but we have to disqualify zbaa from the Western Subregional Programming Contest 2009. The reason is that this contestant has submitted the jury solutions (available on the official website of the contest) with just some cosmetic changes to all problems. It's very sad that such behaviour still sometimes occurs among our contestants. Congratulations to the real winner of the contest - Anton Lunyov, and thanks to everybody who participated in a fair way!</td></tr><tr><td valign=top nowrap><b><br></b></td><td></td></tr><tr><td valign=top nowrap><b>07.11.09</b> - </td><td>The problemset for "XII Western Subregional Contest" is
<a href="problems/34/problems34-lg.pdf">available as PDF</a>.</td></tr><tr><td valign=top nowrap><b><br></b></td><td></td></tr><tr><td valign=top nowrap><b>30.10.09</b> - </td><td>Problems from the Halloween Contest 2009 were added to the problemset archive.</td></tr><tr><td valign=top nowrap><b><br></b></td><td></td></tr><tr><td valign=top nowrap><b>30.10.09</b> - </td><td><b>Clarification</b> for the problem K: the line "If the bottle reaches an empty cell in the lowest row, it falls to the tray and Vasya can take it." should be replaced by "If the bottle falls down from the lowest row, it falls to the tray and Vasya can take it."</td></tr><tr><td valign=top nowrap><b><br></b></td><td></td></tr><tr><td valign=top nowrap><b>30.10.09</b> - </td><td>The problemset for "Halloween Contest 2009" is
<a href="problems/33/problems33.pdf">available as PDF</a>.</td></tr><tr><td valign=top nowrap><b><br></b></td><td></td></tr><tr><td valign=top nowrap><b>28.10.09</b> - </td><td>Some participants have provided obviously <b>fake</b> information about their names and cities while registering to Halloween Contest 2009. We will exclude them from the list of the registered users, so they will have to register again. Please, provide your <b>real</b> names and cities. This information will be used only to make a statistical report about the contest.</td></tr><tr><td valign=top nowrap><b><br></b></td><td></td></tr><tr><td valign=top nowrap><b>23.10.09</b> - </td><td>The problemset for "Goryinyich Challenge X" is
<a href="problems/32/problems32.pdf">available as PDF</a>.</td></tr><tr><td valign=top nowrap><b><br></b></td><td></td></tr><tr><td valign=top nowrap><b>15.10.09</b> - </td><td>We are glad to announce that we have supported C# programming language. We use <a href="http://www.mono-project.com/Main_Page">mono C# compiler gmcs</a> to compile your code.</td></tr><tr><td valign=top nowrap><b><br></b></td><td></td></tr><tr><td valign=top nowrap><b>15.10.09</b> - </td><td>We've upgraded MinGW installation to use g++.EXE (TDM-2 mingw32) 4.4.1. You can download the compiler <a href="http://www.tdragon.net/recentgcc/">[here]</a>.</td></tr><tr><td valign=top nowrap><b><br></b></td><td></td></tr><tr><td valign=top nowrap><b>11.10.09</b> - </td><td>The problemset for "Southern Subregional Programming Contest 2009" is
<a href="problems/31/problems31.pdf">available as PDF</a>.</td></tr><tr><td valign=top nowrap><b><br></b></td><td></td></tr><tr><td valign=top nowrap><b>25.09.09</b> - </td><td>Current contest statements are <a href="problems/30/problems30.pdf">available as PDF</a>.</td></tr><tr><td valign=top nowrap><b><br></b></td><td></td></tr><tr><td valign=top nowrap><b>11.08.09</b> - </td><td>The final <a href="materials/sazanka2009/stats.htm">results</a> of summer contest series in Student Summer School in programming and informatics has been published.</td></tr><tr><td valign=top nowrap><b><br></b></td><td></td></tr><tr><td valign=top nowrap><b>04.08.09</b> - </td><td>Current <a href="materials/sazanka2009/stats.htm">results</a> of summer contest series in Student Summer School in programming and informatics has been published. We have no internet here, so the results will be updated one time a day.</td></tr><tr><td valign=top nowrap><b><br></b></td><td></td></tr><tr><td valign=top nowrap><b>09.06.09</b> - </td><td>New version of the testlib is available on <a href="http://code.google.com/p/testlib/" target="_blank">the project site</a>.
This version supports validators and generators out of the box. Visit the project site to read the details.
</td></tr><tr><td valign=top nowrap><b><br></b></td><td></td></tr><tr><td valign=top nowrap><b>21.05.09</b> - </td><td><font color="aa0000">Saratov State University</font> is planning to organize Student Summer School in programming and informatics. 
Click <a href="camp-2009-information-1.html">[here]</a> to the read detailed information in Russian.    
</td></tr><tr><td valign=top nowrap><b><br></b></td><td></td></tr><tr><td valign=top nowrap><b>24.04.09</b> - </td><td><font color="aa0000">Saratov State University</font> won <font color="aa0000">Gold medals</font> on ACM-ICPC World Finals!
Team <font color="aa0000">"Saratov SU #1" (Natalya Bondarenko, Dmitry Matov, Stanislav Pak)</font>
solved 8 problems with time 1305 minutes and take fourth place.
Also we want to congratulate St. Petersburg State University of IT, Mechanics and Optics,
Tsinghua University and St. Petersburg State University, whose teams took first,
second and third places respectively.</td></tr><tr><td valign=top nowrap><b><br></b></td><td></td></tr><tr><td valign=top nowrap><b>06.04.09</b> - </td><td>New realese of the testlib library is available on <a href="http://code.google.com/p/testlib/" target="_blank">project site</a>. Fixed issue about Linux compilation, added InStream::readLong() and prewritten checkers updated.</td></tr><tr><td valign=top nowrap><b><br></b></td><td></td></tr><tr><td valign=top nowrap><b>21.02.09</b> - </td><td>We are glad to announce that new contests are coming. Here's a message from the problemsetters: 

<br/>
<i>
I'd like to invite you all to two more contests I've been authoring recently. 
Petr Mitrichev Contest 3 (including problems by Michael Levin and Irina Shitova) will take place on 

<a href="http://www.timeanddate.com/worldclock/fixedtime.html?day=1&month=3&year=2009&hour=11&min=0&sec=0&p1=166">March 1, 2009 11:00</a> (Moscow Time),
 
and Petr, Michael_Levin and VitalyGoldstein Contest (aka Petr Mitrichev Contest 4) will take place on 

<a href="http://www.timeanddate.com/worldclock/fixedtime.html?day=15&month=3&year=2009&hour=11&min=0&sec=0&p1=166">March 15, 2009 11:00</a> (Moscow Time). 

These contests were set earlier at the Petrozavodsk training camps. Best of luck, <font color="red"><b>Petr</b></font>.
</i>
<br/>

Do not take part in the contest if you already were solving the problems from it.
</td></tr><tr><td valign=top nowrap><b><br></b></td><td></td></tr><tr><td valign=top nowrap><b>26.10.08</b> - </td><td>Russian version of the problem statements for today contest are available in <a href = problems/26/problems-rus.ps>PS</a> or <a href = problems/26/problems-rus.pdf>PDF</a> format.</td></tr></table></td></tr></table></td></tr></table><br></td> <!-- close middle colomn -->
<td width=5><img src="pixel.gif" alt="" width=5 height=1></td>
<td valign="top">
<table width=153.6 class=tb cellpadding=0 cellspacing=0><tr><td><table width=153.6 cellspacing=1 ><tr><td bgcolor=#6587B9> ::Login</td></tr><tr><td bgcolor=#FFFFFF> <style>form.login input{margin:2px;font-size:10px;}</style>    <form class=login action=login.php method=post>
    your id:<br>
    <input type=hidden name=redirect_uri value='/news.php'>
    <input class=inp style="width: 104px; height: 18px; font-size: 10px" maxLength=16 size=5 name=try_user_id value=''>
    <br>
    password:<br>
    <input class=inp style="width: 62px; height: 18px; font-size: 10px" type=password maxLength=16 size=3 name=try_user_password value=''>
    <input type=hidden name=type_log value="login">
    <input class=frm style="width: 45px" type=submit value=Login> 
    </form>
    <a style="font-size:10px;position:relative;bottom:5px;left:2px;" href="forgot_password.php">Forgot password?</a>
    </td></tr></table></td></tr></table><br><table width=153.6 class=tb cellpadding=0 cellspacing=0><tr><td><table width=153.6 cellspacing=1 >
<tr><td bgcolor=#6587B9> ::News</td></tr><tr><td bgcolor=#FFFFFF> <b>22.10.12</b> - The problems from the Southern Subregional Programming Contest 2012 added to the problemset archive (542 - 553). <br><b>22.10.12</b> - After the start of the contest the statements in PDF will be available <a href="http://acm.sgu.ru/problems/39/problems39.pdf">by the link</a>.<br><b>23.10.11</b> - The problems from the Southern Subregional Programming Contest 2011 added to the problemset archive (530 - 541).
<br></td></tr></table></td></tr></table><br><table width=153.6 class=tb cellpadding=0 cellspacing=0><tr><td><table width=153.6 cellspacing=1 >
<tr><td bgcolor=#6587B9> ::Counter</td></tr><tr><td bgcolor=#FFFFFF> 
<table align=center>
<tr>
<td>
<!-- google -->
<script src="http://www.google-analytics.com/urchin.js" type="text/javascript">
</script>
<script type="text/javascript">
_uacct = "UA-743380-1";
urchinTracker();
</script>
<!-- SpyLOG f:0211 --> 
<script language="javascript"><!-- 
Mu="u4199.99.spylog.com";Md=document;Mnv=navigator;Mp=0; 
Md.cookie="b=b";Mc=0;if(Md.cookie)Mc=1;Mrn=Math.random(); 
Mn=(Mnv.appName.substring(0,2)=="Mi")?0:1;Mt=(new Date()).getTimezoneOffset(); 
Mz="p="+Mp+"&rn="+Mrn+"&c="+Mc+"&t="+Mt; 
if(self!=top){Mfr=1;}else{Mfr=0;}Msl="1.0"; 
//--></script><script language="javascript1.1"><!-- 
Mpl="";Msl="1.1";Mj = (Mnv.javaEnabled()?"Y":"N");Mz+='&j='+Mj; 
//--></script><script language="javascript1.2"><!-- 
Msl="1.2";Ms=screen;Mpx=(Mn==0)?Ms.colorDepth:Ms.pixelDepth; 
Mz+="&wh="+Ms.width+'x'+Ms.height+"&px="+Mpx; 
//--></script><script language="javascript1.3"><!-- 
Msl="1.3";//--></script><script language="javascript"><!-- 
My="";My+="<a href='http://"+Mu+"/cnt?cid=419999&f=3&p="+Mp+"&rn="+Mrn+"' target='_blank'>"; 
My+="<img src='http://"+Mu+"/cnt?cid=419999&"+Mz+"&sl="+Msl+"&r="+escape(Md.referrer)+"&fr="+Mfr+"&pg="+escape(window.location.href); 
My+="' border=0 width=88 height=31 alt='SpyLOG'>"; 
My+="</a>";Md.write(My);//--></script><noscript> 
<a href="http://u4199.99.spylog.com/cnt?cid=419999&f=3&p=0" target="_blank"> 
<img src="http://u4199.99.spylog.com/cnt?cid=419999&p=0" alt='SpyLOG' border='0' width=88 height=31 > 
</a></noscript> 
<!-- SpyLOG -->

</td>
</tr>
</table>

<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
var pageTracker = _gat._getTracker("UA-5412771-1");
pageTracker._trackPageview();
</script>

  </td></tr></table></td></tr></table><br></tr>
</table><table width=984 class=tb cellpadding=0 cellspacing=0><tr><td><table width=984 cellspacing=1 ><tr><td bgcolor=#FFFFFF> <table width=100% cellpadding=0 cellspacing=0 border=0><tr style='background-color : #FFFFFF;'><td align=left>Server time: 2013-11-14 21:38:03</td><td align=right><a target=_top href='mailto:acm@sgu.ru'>Online Contester</a> Team &copy; 2002 - 2013. All rights reserved.</td></tr></table></td></tr></table></td></tr></table></div></body></html>