<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Saratov State University :: Online Contester</title>
<META content="text/html; charset=windows-1251" http-equiv=Content-Type>
<META NAME="keywords" CONTENT="???">
<META NAME="description" CONTENT="???">
<meta name="google-site-verification" content="YvG5TvZLtlRLnK2EX22Dz815tDU7UKdDeXE_yJQp3cQ" />
<meta name="verify-v1" content="MCzwwWrZt7qOC1A2HZusdjMbXjHR+zXtTCKpx2CRSEU=" />

  <link rel="stylesheet" href="/templates.css" type="text/css">
  <link rel="stylesheet" href="/js/ui.datepicker.css" type="text/css">
  <script type="text/javascript" language="javascript" src="/js/jquery.js"></script>
  <script type="text/javascript" language="javascript" src="/js/jquery.example.js"></script>
  <script type="text/javascript" language="javascript" src="/js/ui.datepicker.js"></script>

  <link rel="stylesheet" href="templates.css" type="text/css">
  <link rel="stylesheet" href="js/ui.datepicker.css" type="text/css">
  <script type="text/javascript" language="javascript" src="js/jquery.js"></script>
  <script type="text/javascript" language="javascript" src="js/jquery.example.js"></script>
  <script type="text/javascript" language="javascript" src="js/ui.datepicker.js"></script>
<!--[if IE 6]>
<script type="text/javascript"> 
    /*Load jQuery if not already loaded*/ if(typeof jQuery == 'undefined'){ document.write("<script type=\"text/javascript\"   src=\"http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js\"></"+"script>"); var __noconflict = true; } 
    var IE6UPDATE_OPTIONS = {
        icons_path: "http://static.ie6update.com/hosted/ie6update/images/"
    }
</script>
<script type="text/javascript" src="http://static.ie6update.com/hosted/ie6update/ie6update.js"></script>
<![endif]-->
<link rel="stylesheet" href="style-1024.css" type="text/css">
</head>      <body bgcolor=#F3F6F9 text=#000000 link=#336699 vlink=#336699 alink=#336699><div align="center">
    <table width=984 class=tb cellpadding=0 cellspacing=0><tr><td><table width=984 cellspacing=1 ><tr><td bgcolor=#6587B9> <h3 align=center><font face='Geneva'><b style='color: White'>Saratov State University :: Online Contester</b></font></h3></td></tr></table></td></tr></table><br>    
<table width="974" border="0" cellpadding="0" cellspacing="0">
<tr>
<td valign="top">
<table width=153.6 class=tb cellpadding=0 cellspacing=0><tr><td><table width=153.6 cellspacing=1 ><tr><td bgcolor=#6587B9> ::Go</td></tr><tr><td bgcolor=#FFFFFF> - <a href = index.php> home </a><br>- <a href = news.php> news </a><br>- <a href = 'register.php'> register </a><br><table border=0 cellpadding=0 cellspacing=0><tr><td valign=top>-</td><td>&nbsp;</td><td><a href = 'update.php'>update personal info</a></td></tr></table><table border=0 cellpadding=0 cellspacing=0><tr><td valign=top>-</td><td>&nbsp;</td><td><a href = 'problemset.php?show_volumes'>problemset archive</a></td></tr></table>- <a href = submit.php> submit </a><br>- <a href = status.php> status online </a><br>- <a href = standing.php> standing </a><br>- <a href = contests.php> contests </a><br>- <a href = vcontests.php> virtual contests </a><br>- <a href = forum.php> forum </a><br>- <a href = statistic.php> statistic </a><br>- <a href = faq.php> FAQ </a><br>- <a href = links.php> links </a><br>- <a href = projects.php> projects </a></table></td></tr></table><br><table width=153.6 class=tb cellpadding=0 cellspacing=0><tr><td><table width=153.6 cellspacing=1 >
<tr><td bgcolor=#6587B9> ::Poll</td></tr>  <tr><td bgcolor=#FFFFFF> Are you registered on <a href="http://codeforces.com">Codeforces</a>?<br><form action=poll_action.php method=post target=_blank><input type=hidden name=poll value=14><input type=radio name=choose value=1 checked>Yes<br><input type=radio name=choose value=2 >No<br><input type=radio name=choose value=3 >What is it???<br><input type=submit value=Send class='frm' style='width:70px; font: 9;'><a href = poll_result.php?poll=14><br>[results]</a></form></td></tr></table></td></tr></table><br></td> <!-- close left colomn -->
<td width=5><img src="pixel.gif" alt="" width=5 height=1></td>
<td valign="top">
<table width=640 class=tb cellpadding=0 cellspacing=0><tr><td><table width=640 cellspacing=1 ><tr><td bgcolor=#6587B9> <div align=left class=dh>::register</div></td></tr><tr><td bgcolor=#FFFFFF> 
<script language = "JavaScript" >
function checkform() {
  if (navigator.appName != 'Microsoft Internet Explorer') {return 1};
  for ( i = 0; i < 11; i++ ) {
    if ( document.forms[1].elements[i].value.length == 0 ) {
      alert( "Fill in all fields" );
      return 0;
    };
  };
  return 1;
};
</script>

<TABLE cellSpacing=0 cellPadding=0 width="80%" border=0 align=center>
  <TBODY>
  <TR>
    <TD><BR><BR>
      <FORM action=register.php method=post><INPUT type=hidden value=1 
      name=register> 
      <TABLE cellSpacing=0 cellPadding=0 width="100%" border=0 class=btab>
        <TBODY>
        <TR>
          <TD width=100>Your Name:</TD>
          <TD><INPUT name=name class=inp></TD></TR>
        <TR>
          <TD>Your E-Mail:</TD>
          <TD><INPUT name=email class=inp> Do not publish your mail: <INPUT name=nopublishmail type=checkbox value="1"></TD></TR>
        <TR>
          <TD>Country:</TD>
          <TD><SELECT name=country> 
          <OPTION value=?? selected>Select your country:
          <OPTION value=AI>ANGUILLA<OPTION value=AQ>ANTARCTICA<OPTION value=AR>ARGENTINA<OPTION value=AM>ARMENIA<OPTION value=AU>AUSTRALIA<OPTION value=AT>AUSTRIA<OPTION value=AZ>AZERBAIJAN<OPTION value=BH>BAHRAIN<OPTION value=BD>BANGLADESH<OPTION value=BY>BELARUS<OPTION value=BE>BELGIUM<OPTION value=BO>BOLIVIA<OPTION value=BA>BOSNIA AND HERZEGOWINA<OPTION value=BR>BRAZIL<OPTION value=BG>BULGARIA<OPTION value=CA>CANADA<OPTION value=TD>CHAD<OPTION value=CL>CHILE<OPTION value=CN>CHINA<OPTION value=CX>CHRISTMAS ISLAND<OPTION value=CO>COLOMBIA<OPTION value=CK>COOK ISLANDS<OPTION value=HR>CROATIA<OPTION value=CU>CUBA<OPTION value=CY>CYPRUS<OPTION value=CZ>CZECH REPUBLIC<OPTION value=DK>DENMARK<OPTION value=DO>DOMINICAN REPUBLIC<OPTION value=??>Earth is my Motherland!<OPTION value=EG>EGYPT<OPTION value=SV>EL SALVADOR<OPTION value=EE>ESTONIA<OPTION value=FI>FINLAND<OPTION value=FR>FRANCE<OPTION value=GE>GEORGIA<OPTION value=DE>GERMANY<OPTION value=GR>GREECE<OPTION value=GT>GUATEMALA<OPTION value=HN>HONDURAS<OPTION value=HK>HONG KONG<OPTION value=HU>HUNGARY<OPTION value=IN>INDIA<OPTION value=ID>INDONESIA<OPTION value=IR>IRAN (ISLAMIC REPUBLIC OF)<OPTION value=IE>IRELAND<OPTION value=IL>ISRAEL<OPTION value=IT>ITALY<OPTION value=JM>JAMAICA<OPTION value=JP>JAPAN<OPTION value=KZ>KAZAKHSTAN<OPTION value=KP>KOREA, DEMOCRATIC PEOPLE"S REPUBLIC OF<OPTION value=KR>KOREA, REPUBLIC OF<OPTION value=KW>KUWAIT<OPTION value=KG>KYRGYZSTAN<OPTION value=LA>LAO PEOPLE"S DEMOCRATIC REPUBLIC<OPTION value=LV>LATVIA<OPTION value=LY>LIBYAN ARAB JAMAHIRIYA<OPTION value=LT>LITHUANIA<OPTION value=LU>LUXEMBOURG<OPTION value=MO>MACAU<OPTION value=MK>MACEDONIA<OPTION value=MY>MALAYSIA<OPTION value=MV>MALDIVES<OPTION value=MX>MEXICO<OPTION value=ML>MOLDOVA<OPTION value=MA>MOROCCO<OPTION value=MZ>MOZAMBIQUE<OPTION value=NP>NEPAL<OPTION value=NL>NETHERLANDS<OPTION value=AN>NETHERLANDS ANTILLES<OPTION value=NZ>NEW ZEALAND<OPTION value=NI>NICARAGUA<OPTION value=NG>NIGERIA<OPTION value=NO>NORWAY<OPTION value=OM>OMAN<OPTION value=PK>PAKISTAN<OPTION value=PY>PARAGUAY<OPTION value=PE>PERU<OPTION value=PH>PHILIPPINES<OPTION value=PL>POLAND<OPTION value=PT>PORTUGAL<OPTION value=PR>PUERTO RICO<OPTION value=RO>ROMANIA<OPTION value=RU>RUSSIAN FEDERATION<OPTION value=SM>SAN MARINO<OPTION value=SG>SINGAPORE<OPTION value=SK>SLOVAKIA (Slovak Republic)<OPTION value=SI>SLOVENIA<OPTION value=ZA>SOUTH AFRICA<OPTION value=ES>SPAIN<OPTION value=SE>SWEDEN<OPTION value=CH>SWITZERLAND<OPTION value=TW>TAIWAN<OPTION value=TZ>TANZANIA, UNITED REPUBLIC OF<OPTION value=TH>THAILAND<OPTION value=TT>TRINIDAD AND TOBAGO<OPTION value=TR>TURKEY<OPTION value=TM>TURKMENISTAN<OPTION value=UA>UKRAINE<OPTION value=AE>UNITED ARAB EMIRATES<OPTION value=UK>UNITED KINGDOM<OPTION value=US>UNITED STATES<OPTION value=UY>URUGUAY<OPTION value=UZ>UZBEKISTAN<OPTION value=VE>VENEZUELA<OPTION value=VN>VIET NAM<OPTION value=EH>WESTERN SAHARA<OPTION value=YU>YUGOSLAVIA<OPTION value=ZW>ZIMBABWE        </OPTION></SELECT> </TD></TR>
        <TR>
          <TD colSpan=2><BR>
            <HR>
            <BR></TD></TR>
        <TR>
          <TD>Your Password:</TD>
          <TD><INPUT type=password name=pass1 class=inp></TD></TR>
        <TR>
          <TD>Confirm Password:</TD>
          <TD><INPUT type=password name=pass2 class=inp></TD></TR>
        <TR>
          <TD colSpan=2></TD></TR>
        <TR>
          <TD colSpan=2><BR>
            <HR>
            <BR></TD></TR>
        <TR>
          <TD>Full Name:</TD>
          <TD><INPUT name=fullname class=inp></TD></TR>
        <TR>
          <TD colSpan=2>Note: Type your <B>full real (!)</B> name. It can't be nick or something of the kind. </TD></TR>
        <TR>
          <TD colSpan=2><BR>
            <HR>
            <BR></TD></TR>
        <TR>
          <TD>Study place:</TD>
          <TD><INPUT name=studyplace class=inp></TD></TR>
        <TR>
          <TD colSpan=2>Note: Type university, college or school <B>full name (!)</B> where you are studing. You can write name of university you graduated from. <B>Do not use abbreviation, such as SSGTU or like.</B></TD></TR>
        <TR>
          <TD colSpan=2><BR>
            <HR>
            <BR></TD></TR>
        <TR><td>Birthday: </td><td><table><tr>
          <TD>Year:</TD>
          <TD><SELECT name=year><OPTION value=""> <OPTION value=1950>1950<OPTION value=1951>1951<OPTION value=1952>1952<OPTION value=1953>1953<OPTION value=1954>1954<OPTION value=1955>1955<OPTION value=1956>1956<OPTION value=1957>1957<OPTION value=1958>1958<OPTION value=1959>1959<OPTION value=1960>1960<OPTION value=1961>1961<OPTION value=1962>1962<OPTION value=1963>1963<OPTION value=1964>1964<OPTION value=1965>1965<OPTION value=1966>1966<OPTION value=1967>1967<OPTION value=1968>1968<OPTION value=1969>1969<OPTION value=1970>1970<OPTION value=1971>1971<OPTION value=1972>1972<OPTION value=1973>1973<OPTION value=1974>1974<OPTION value=1975>1975<OPTION value=1976>1976<OPTION value=1977>1977<OPTION value=1978>1978<OPTION value=1979>1979<OPTION value=1980>1980<OPTION value=1981>1981<OPTION value=1982>1982<OPTION value=1983>1983<OPTION value=1984>1984<OPTION value=1985>1985<OPTION value=1986>1986<OPTION value=1987>1987<OPTION value=1988>1988<OPTION value=1989>1989<OPTION value=1990>1990<OPTION value=1991>1991<OPTION value=1992>1992<OPTION value=1993>1993<OPTION value=1994>1994<OPTION value=1995>1995<OPTION value=1996>1996<OPTION value=1997>1997<OPTION value=1998>1998<OPTION value=1999>1999<OPTION value=2000>2000<OPTION value=2001>2001<OPTION value=2002>2002<OPTION value=2003>2003<OPTION value=2004>2004<OPTION value=2005>2005<OPTION value=2006>2006<OPTION value=2007>2007<OPTION value=2008>2008<OPTION value=2009>2009</OPTION></SELECT> </TD><TD></TD>
          <TD>Month:</TD>
          <TD><SELECT name=month><OPTION value=""> <OPTION value=01>01<OPTION value=02>02<OPTION value=03>03<OPTION value=04>04<OPTION value=05>05<OPTION value=06>06<OPTION value=07>07<OPTION value=08>08<OPTION value=09>09<OPTION value=10>10<OPTION value=11>11<OPTION value=12>12</OPTION></SELECT> </TD><TD></TD><TD>Day:</TD>
          <TD><SELECT name=day><OPTION value=""> <OPTION value=01>01<OPTION value=02>02<OPTION value=03>03<OPTION value=04>04<OPTION value=05>05<OPTION value=06>06<OPTION value=07>07<OPTION value=08>08<OPTION value=09>09<OPTION value=10>10<OPTION value=11>11<OPTION value=12>12<OPTION value=13>13<OPTION value=14>14<OPTION value=15>15<OPTION value=16>16<OPTION value=17>17<OPTION value=18>18<OPTION value=19>19<OPTION value=20>20<OPTION value=21>21<OPTION value=22>22<OPTION value=23>23<OPTION value=24>24<OPTION value=25>25<OPTION value=26>26<OPTION value=27>27<OPTION value=28>28<OPTION value=29>29<OPTION value=30>30<OPTION value=31>31</OPTION></SELECT> </TD></tr></table></td>
        <TR>
          <TD colSpan=2><BR>
            <HR>
            <BR></TD></TR>
        <TR>
          <TD colSpan=2>Information:<BR>
          <textarea cols="60" name="info" rows="5" wrap="virtual" class=inp></textarea>
          </TD></TR>
        <TR>
          <TD colSpan=2>Note: Here write something about you, your personality. You can write about you best results in the field of programming contests.<BR> Note: if you want to register a team then list all it's members and information about them. It is an obligatory rule.</TD></TR>
        <TR>
          <TD colSpan=2><BR>
            <HR>
            <BR></TD></TR>
        <TR>
          <TD colSpan=2><B>Note:</B> You must fill register form correctly and honestly. <B>Don't miss any fields or write wrong information.</B> Online Contester Team may disqualify you if you write inccorect facts wittingly. Besides, it will be interesting for you to know detailed information about other teams.</TD></TR>
        <TR>
          <TD colSpan=2><BR>
            <HR>
            <BR></TD></TR>
<!--begin of captcha -->
<!--

        <TR>
          <TD>Code:</TD>
          <TD><img id="captcha" src="/securimage/securimage_show.php" alt="CAPTCHA Image" /></TD></TR>
        <TR>
          <TD>Confirm Code:</TD>
          <TD style="height:3em;"><input type="text" name="captcha_code" size="10" maxlength="6" /></TD></TR>
-->
<!--end of captcha-->

        <TR>
          <TD colSpan=2><BR>
            <HR>
            <BR></TD></TR>
        <TR>
        <TR>
          <TD align=middle 
        colSpan=2><INPUT type=button value=register onClick="if ( checkform() ) { document.forms[1].submit(); } ;" class=frm></TD></TR></TBODY></TABLE></FORM><BR><BR></TD>
    </TR>
  <TR>
    <TD colSpan=3>
    </TD></TR></TBODY></TABLE>

</td></tr></table></td></tr></table><br></td> <!-- close middle colomn -->
<td width=5><img src="pixel.gif" alt="" width=5 height=1></td>
<td valign="top">
<table width=153.6 class=tb cellpadding=0 cellspacing=0><tr><td><table width=153.6 cellspacing=1 ><tr><td bgcolor=#6587B9> ::Login</td></tr><tr><td bgcolor=#FFFFFF> <style>form.login input{margin:2px;font-size:10px;}</style>    <form class=login action=login.php method=post>
    your id:<br>
    <input type=hidden name=redirect_uri value='/register.php'>
    <input class=inp style="width: 104px; height: 18px; font-size: 10px" maxLength=16 size=5 name=try_user_id value=''>
    <br>
    password:<br>
    <input class=inp style="width: 62px; height: 18px; font-size: 10px" type=password maxLength=16 size=3 name=try_user_password value=''>
    <input type=hidden name=type_log value="login">
    <input class=frm style="width: 45px" type=submit value=Login> 
    </form>
    <a style="font-size:10px;position:relative;bottom:5px;left:2px;" href="forgot_password.php">Forgot password?</a>
    </td></tr></table></td></tr></table><br><table width=153.6 class=tb cellpadding=0 cellspacing=0><tr><td><table width=153.6 cellspacing=1 >
<tr><td bgcolor=#6587B9> ::News</td></tr><tr><td bgcolor=#FFFFFF> <b>22.10.12</b> - The problems from the Southern Subregional Programming Contest 2012 added to the problemset archive (542 - 553). <br><b>22.10.12</b> - After the start of the contest the statements in PDF will be available <a href="http://acm.sgu.ru/problems/39/problems39.pdf">by the link</a>.<br><b>23.10.11</b> - The problems from the Southern Subregional Programming Contest 2011 added to the problemset archive (530 - 541).
<br></td></tr></table></td></tr></table><br><table width=153.6 class=tb cellpadding=0 cellspacing=0><tr><td><table width=153.6 cellspacing=1 >
<tr><td bgcolor=#6587B9> ::Counter</td></tr><tr><td bgcolor=#FFFFFF> 
<table align=center>
<tr>
<td>
<!-- google -->
<script src="http://www.google-analytics.com/urchin.js" type="text/javascript">
</script>
<script type="text/javascript">
_uacct = "UA-743380-1";
urchinTracker();
</script>
<!-- SpyLOG f:0211 --> 
<script language="javascript"><!-- 
Mu="u4199.99.spylog.com";Md=document;Mnv=navigator;Mp=0; 
Md.cookie="b=b";Mc=0;if(Md.cookie)Mc=1;Mrn=Math.random(); 
Mn=(Mnv.appName.substring(0,2)=="Mi")?0:1;Mt=(new Date()).getTimezoneOffset(); 
Mz="p="+Mp+"&rn="+Mrn+"&c="+Mc+"&t="+Mt; 
if(self!=top){Mfr=1;}else{Mfr=0;}Msl="1.0"; 
//--></script><script language="javascript1.1"><!-- 
Mpl="";Msl="1.1";Mj = (Mnv.javaEnabled()?"Y":"N");Mz+='&j='+Mj; 
//--></script><script language="javascript1.2"><!-- 
Msl="1.2";Ms=screen;Mpx=(Mn==0)?Ms.colorDepth:Ms.pixelDepth; 
Mz+="&wh="+Ms.width+'x'+Ms.height+"&px="+Mpx; 
//--></script><script language="javascript1.3"><!-- 
Msl="1.3";//--></script><script language="javascript"><!-- 
My="";My+="<a href='http://"+Mu+"/cnt?cid=419999&f=3&p="+Mp+"&rn="+Mrn+"' target='_blank'>"; 
My+="<img src='http://"+Mu+"/cnt?cid=419999&"+Mz+"&sl="+Msl+"&r="+escape(Md.referrer)+"&fr="+Mfr+"&pg="+escape(window.location.href); 
My+="' border=0 width=88 height=31 alt='SpyLOG'>"; 
My+="</a>";Md.write(My);//--></script><noscript> 
<a href="http://u4199.99.spylog.com/cnt?cid=419999&f=3&p=0" target="_blank"> 
<img src="http://u4199.99.spylog.com/cnt?cid=419999&p=0" alt='SpyLOG' border='0' width=88 height=31 > 
</a></noscript> 
<!-- SpyLOG -->

</td>
</tr>
</table>

<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
var pageTracker = _gat._getTracker("UA-5412771-1");
pageTracker._trackPageview();
</script>

  </td></tr></table></td></tr></table><br></tr>
</table><table width=984 class=tb cellpadding=0 cellspacing=0><tr><td><table width=984 cellspacing=1 ><tr><td bgcolor=#FFFFFF> <table width=100% cellpadding=0 cellspacing=0 border=0><tr style='background-color : #FFFFFF;'><td align=left>Server time: 2013-11-14 21:38:03</td><td align=right><a target=_top href='mailto:acm@sgu.ru'>Online Contester</a> Team &copy; 2002 - 2013. All rights reserved.</td></tr></table></td></tr></table></td></tr></table></div></body></html>